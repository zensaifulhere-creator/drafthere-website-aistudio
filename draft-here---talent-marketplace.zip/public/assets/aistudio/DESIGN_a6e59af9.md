---
name: Cinematic Editorial Marketplace
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0edec'
  surface-container-high: '#ebe7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#56423f'
  inverse-surface: '#313030'
  inverse-on-surface: '#f3f0ef'
  outline: '#89726e'
  outline-variant: '#ddc0bc'
  surface-tint: '#a03e35'
  primary: '#360001'
  on-primary: '#ffffff'
  primary-container: '#590907'
  on-primary-container: '#e17063'
  inverse-primary: '#ffb4aa'
  secondary: '#5d5f55'
  on-secondary: '#ffffff'
  secondary-container: '#e2e4d6'
  on-secondary-container: '#63655b'
  tertiary: '#1e1404'
  on-tertiary: '#ffffff'
  tertiary-container: '#352815'
  on-tertiary-container: '#a18f75'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad5'
  primary-fixed-dim: '#ffb4aa'
  on-primary-fixed: '#410001'
  on-primary-fixed-variant: '#812720'
  secondary-fixed: '#e2e4d6'
  secondary-fixed-dim: '#c6c8bb'
  on-secondary-fixed: '#1a1d15'
  on-secondary-fixed-variant: '#45483e'
  tertiary-fixed: '#f6dfc2'
  tertiary-fixed-dim: '#d9c3a7'
  on-tertiary-fixed: '#251a08'
  on-tertiary-fixed-variant: '#53442f'
  background: '#fcf9f8'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
typography:
  display-hero:
    fontFamily: Space Grotesk
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.025em
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 24px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 17px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Space Grotesk
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Space Grotesk
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-2xl: 4rem
---

## Brand & Style
The design system positions the creative talent marketplace at the intersection of haute editorial publishing and razor-sharp digital craft. Unlike commoditized freelance platforms that feel transactional or sterile, this platform evokes exclusivity, curated craftsmanship, and agency-tier confidence. The brand personality is bold, architectural, and tactile—treating portfolios, creative services, and talent curation like museum exhibitions or high-fashion editorial lookbooks.

The aesthetic fuses **Minimalism** with **High-Contrast Editorial** nuances:
- Architectural discipline anchored by pure obsidian dark accents and warm, natural material undertones (linen, stone, and oxblood).
- Sharp geometric elements derived directly from the angular identity (geometric diagonals, sharp monogram dynamics, and precision badges).
- Generous breathing room paired with ultra-crisp hairline dividers, creating a sense of luxury, prestige, and quiet competence.

## Colors
The palette balances visceral editorial intensity with soothing, textural warmth:

- **Primary (`#590907` - Deep Oxblood / Burgundy):** Anchors high-priority actions, active tabs, talent verification highlights, and dramatic visual accents. Evokes prestige and high craft. A vibrant red (`#E01A22`) is reserved strictly for acute graphical punctuation matching the monogram's geometric accent.
- **Secondary (`#A5A79B` - Muted Sage / Slate):** A calming, neutral mid-tone used for secondary metadata, subtle borders, inactive pill filters, and neutral badge backgrounds.
- **Tertiary (`#E8D2B5` - Warm Cream Linen):** Softens the workspace, offering an alternative warm background tier for highlighted tier packages, featured pro cards, and editorial quote panels.
- **Neutral (`#121212` - Obsidian Dark):** Provides high-contrast, razor-sharp typography, dark-mode surfaces, hero banners, and dominant navigation frames.
- **Canvas Base (`#FAF9F6` - Off-White Canvas):** Clean, non-fatiguing gallery white that keeps cards elevated without harsh hospital-glare clinical whites.

## Typography
Typography is paired to deliver editorial authority alongside high-density transactional efficiency:

- **Headlines & Display (`Space Grotesk`):** Infuses technological precision and geometric character. Its sharp apexes and modern proportions harmonise directly with the geometric branding monogram. Display sizes employ tighter tracking (`-0.02em` to `-0.03em`) to mimic magazine titling.
- **Body & Longform (`Hanken Grotesk`):** Provides pristine humanist legibility across gig descriptions, talent bios, and multi-tier pricing specifications.
- **Labels & Microcopy (`Space Grotesk` uppercase / tabular):** Used for pricing metrics, review numbers, currency tags, and talent capability badges to ground data in industrial clarity.

## Layout & Spacing
The layout leverages a structural **Fluid Grid** architecture built on an 8pt spatial baseline:

- **Desktop (12 columns):** 1200px to 1440px max content bounding container with `3rem` section margins and `1.5rem` gutters. Marketplace catalog views support 3-column service cards or 4-column talent preview grids.
- **Tablet (8 columns):** `2rem` outer margins, `1rem` gutters. Marketplace cards scale to 2-column configurations with persistent horizontal scroll for category carousels.
- **Mobile (4 columns):** `1.25rem` outer margins, single-column full-width cards with side-snapping category chips and stacked pricing tables.
- **Rhythm & Density:** Generous macro-spacing (`space-xl` and `space-2xl`) between high-level editorial sections, compressed with disciplined micro-spacing (`space-xs` through `space-md`) within pricing cards and talent meta tags.

## Elevation & Depth
Depth avoids heavy blurs or muddy dropshadows, leaning instead on **Tonal Layers** combined with **Low-Contrast Hairline Outlines** and **Ambient Tinted Shadows**:

- **Hairline Outlines:** All modular cards, tiered packages, and pill inputs are contained by a crisp `1px solid rgba(18, 18, 18, 0.08)` border (or `rgba(165, 167, 155, 0.35)` on sage/cream surfaces).
- **Subtle Ambient Shadows:** Standard interactive cards sit on an ultra-diffused resting shadow: `0 4px 20px -2px rgba(18, 18, 18, 0.04)`. On hover, elements elevate seamlessly to `0 12px 32px -4px rgba(89, 9, 7, 0.08)`, introducing a quiet oxblood-tinted lift.
- **Floating Overlays & Badges:** Navigation headers and sticky action bars utilize frosted obsidian (`rgba(18, 18, 18, 0.85)`) with an `8px` backdrop blur (`backdrop-filter: blur(8px)`), producing a cinematic dark header against the warm canvas.

## Shapes
The shape language implements an intentional, architectural hybrid:

- **Structural Containers (`roundedness: 1`):** Service cards, portfolio tiles, modal dialogues, and pricing tables use tight `0.25rem` (4px) to `0.5rem` (8px) corners. This reinforces the sharp geometric spirit of the platform's monogram.
- **Interactive Controls (Full Pill Exception):** Talent filter pills, status badges, and quick-action chips use full pill rounding (`9999px`) to create an ergonomic, tactile contrast against the crisp rectangular framework of the marketplace grid.

## Components

### Buttons
- **Primary:** Obsidian (`#121212`) or Deep Oxblood (`#590907`) solid fill with white text, `4px` corner radius, `Space Grotesk` medium label, and subtle hover scale transition (`translateY(-1px)`).
- **Secondary / Outline:** Crisp `1px solid #121212` border on transparent background; transitions to `#121212` fill on hover with inverted text.
- **Tertiary Ghost:** No border or fill; uses underlined primary oxblood styling on hover for editorial link interactions.

### Pill Filters & Chips
- Fully rounded pills (`rounded-full`, 32px height) with `12px` horizontal padding.
- **Default:** Off-white canvas surface with hairline slate border (`#A5A79B`) and muted dark text.
- **Active:** Deep Oxblood (`#590907`) fill with pure white typography, or Warm Linen (`#E8D2B5`) with obsidian text for category taxonomies.

### Service & Talent Cards
- Surface background set to `#FFFFFF` framed by a `1px` border (`rgba(18,18,18,0.08)`).
- **Header:** Talent avatar flanked by a verified badge (sharp oxblood triangular icon accent or obsidian check).
- **Media Tier:** 16:9 or 4:3 high-aspect portfolio preview with subtle dark gradient overlay for overlay tags.
- **Footer:** Crisp hairline divider leading to a clear tabular pricing baseline ("From $450") and client rating aggregate.

### Service Pricing Tiers (Basic, Standard, Premium)
- 3-column side-by-side modular grid with equal height.
- **Featured / Recommended Tier:** Shaded in Warm Linen (`#E8D2B5`) with an Obsidian top accent line (`3px solid #590907`), prominent CTA button, and clear breakdown checklists.

### Checkboxes & Radio Buttons
- Crisp `1.5px` border in `#121212` with a `2px` radius for checkboxes; pure circle for radios. Checked state fills with `#590907` displaying a crisp white mark.

### Form Inputs & Search
- Generous 48px height fields with off-white background (`#FAF9F6`), `4px` radius, subtle inner border, and crisp typography. Floating search incorporates pill filters directly within the search bar shell for unified query refinement.