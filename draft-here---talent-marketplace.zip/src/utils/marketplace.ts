import { SubCategory, CategoryTab, MilestonePhase } from '../types';

export const CATEGORIES: CategoryTab[] = [
  { id: 'dev-it', label: 'Dev & IT', icon: 'code' },
  { id: 'ai-automation', label: 'AI & Automation', icon: 'smart_toy' },
  { id: 'design-creative', label: 'Design & Creative', icon: 'palette' },
  { id: 'marketing', label: 'Marketing', icon: 'campaign' },
  { id: 'data-analytics', label: 'Data & Analytics', icon: 'analytics' },
  { id: 'admin-ops', label: 'Admin & Ops', icon: 'support_agent' },
  { id: 'writing-editorial', label: 'Writing & Editorial', icon: 'edit_note' },
  { id: 'video-animation', label: 'Video & Animation', icon: 'movie' },
  { id: 'finance-accounting', label: 'Finance & Accounting', icon: 'account_balance' },
  { id: 'legal-compliance', label: 'Legal & Compliance', icon: 'gavel' },
  { id: 'architecture-3d', label: 'Architecture & 3D', icon: 'view_in_ar' },
];

export const SUBCATEGORIES: SubCategory[] = [
  { id: 'full-stack', title: 'Full Stack Developers', availableCount: '1,227+ available', categoryId: 'dev-it' },
  { id: 'wordpress', title: 'WordPress Specialists', availableCount: '16,944+ available', categoryId: 'dev-it' },
  { id: 'web-dev', title: 'Web Developers', availableCount: '1,828+ available', categoryId: 'dev-it' },
  { id: 'shopify', title: 'Shopify Developers', availableCount: '71,325+ available', categoryId: 'dev-it' },
  { id: 'mobile-dev', title: 'Mobile App Devs', availableCount: '42,907+ available', categoryId: 'dev-it' },
  { id: 'webflow', title: 'Webflow Architects', availableCount: '15,410+ available', categoryId: 'dev-it' },
  { id: 'frontend', title: 'Front-End Engineers', availableCount: '8,722+ available', categoryId: 'dev-it' },
  { id: 'ecommerce', title: 'E-commerce Leads', availableCount: '17,269+ available', categoryId: 'dev-it' },
  { id: 'react-vue', title: 'React & Vue Specialists', availableCount: '23,207+ available', categoryId: 'dev-it' },
  { id: 'bubble', title: 'Bubble.io Engineers', availableCount: '841+ available', categoryId: 'dev-it' },
  
  // Additional categories
  { id: 'ai-agents', title: 'AI Autonomous Agents', availableCount: '4,520+ available', categoryId: 'ai-automation' },
  { id: 'fine-tuning', title: 'LLM Fine-Tuning Architects', availableCount: '2,180+ available', categoryId: 'ai-automation' },
  { id: 'brand-identity', title: 'Brand Systems & Systems', availableCount: '12,400+ available', categoryId: 'design-creative' },
  { id: 'ui-ux', title: 'Principal UI/UX Designers', availableCount: '9,840+ available', categoryId: 'design-creative' },
  { id: 'threejs', title: 'Three.js & WebGL Artists', availableCount: '1,120+ available', categoryId: 'architecture-3d' },
];

export const MILESTONE_PHASES: MilestonePhase[] = [
  {
    id: 'phase-1',
    phaseNum: '01',
    phaseBadge: 'Phase One',
    badgeBg: 'bg-tertiary-fixed',
    badgeTextColor: 'text-on-tertiary-fixed',
    title: 'Post a Scope or Browse Gigs',
    description: 'Define deliverables via our architectural brief generator or select pre-budgeted Pro blueprints with calibrated timelines.',
    specs: [
      { label: 'Scope Calibration', value: 'Under 2 Hours', highlight: false },
      { label: 'Deliverables Format', value: 'Notion / Linear Blueprint', highlight: false },
      { label: 'Escrow Hold', value: '0% upfront fee', highlight: true },
    ],
    actionIcon: 'verified',
  },
  {
    id: 'phase-2',
    phaseNum: '02',
    phaseBadge: 'Phase Two',
    badgeBg: 'bg-secondary-fixed',
    badgeTextColor: 'text-on-secondary-fixed',
    title: 'Collaborate in Safe Workspace',
    description: 'Synchronize iterations within Draft Here’s unified encrypted environment with live staging URLs and IP assignment logs.',
    specs: [
      { label: 'Isolation', value: 'Ephemeral Sandboxes', highlight: false },
      { label: 'IP Audit', value: 'Automatic Git SHA Signoff', highlight: false },
      { label: 'Live Previews', value: 'Vercel / AWS Ephemeral', highlight: true },
    ],
    actionIcon: 'lock',
  },
  {
    id: 'phase-3',
    phaseNum: '03',
    phaseBadge: 'Phase Three',
    badgeBg: 'bg-primary-fixed',
    badgeTextColor: 'text-on-primary-fixed',
    title: 'Milestone Escrow Release',
    description: 'Funds remain secured in independent escrow. Payments release seamlessly only upon explicit signoff of deliverables.',
    specs: [
      { label: 'Multi-Sig Escrow', value: 'Cryptographic Clearance', highlight: false },
      { label: 'IP Release', value: 'Automatic Git SHA Signoff', highlight: false },
      { label: 'Disbursement', value: 'Instant Settlement in 48h', highlight: true },
    ],
    actionIcon: 'account_balance_wallet',
  },
  {
    id: 'phase-4',
    phaseNum: '04',
    phaseBadge: 'Phase Four',
    badgeBg: 'bg-secondary-container',
    badgeTextColor: 'text-on-secondary-fixed',
    title: 'Quality Guarantee & Audit',
    description: 'Rigorous peer inspection, code-review SLAs, and automated test coverage benchmarking prior to final signoff.',
    specs: [
      { label: 'Test Automation', value: '98% Coverage Checks', highlight: false },
      { label: 'Code Inspection', value: 'Bespoke Architectural Audit', highlight: false },
      { label: 'Warranty', value: '30-Day Post-Release Warranty', highlight: true },
    ],
    actionIcon: 'verified',
  },
  {
    id: 'phase-5',
    phaseNum: '05',
    phaseBadge: 'Phase Five',
    badgeBg: 'bg-tertiary-fixed',
    badgeTextColor: 'text-on-tertiary-fixed',
    title: 'IP Assignment & Handover',
    description: 'Perpetual dual-sign intellectual property assignment logs, clean git commit history, and zero-liability indemnity.',
    specs: [
      { label: 'IP Protocol', value: 'Instant Cryptographic Transfer', highlight: false },
      { label: 'Git Provenance', value: 'Clean Repository Ownership', highlight: false },
      { label: 'Legal Shield', value: 'Enterprise Zero-Liability Indemnity', highlight: true },
    ],
    actionIcon: 'shield',
  },
  {
    id: 'phase-6',
    phaseNum: '06',
    phaseBadge: 'Phase Six',
    badgeBg: 'bg-primary-fixed',
    badgeTextColor: 'text-on-primary-fixed',
    title: 'Continuous Guild Support',
    description: 'Seamless transition to dedicated retainer hours, high-availability SLA coverage, and on-demand specialist scale.',
    specs: [
      { label: 'Escalation SLA', value: 'Priority 1-Hour SLA', highlight: false },
      { label: 'Talent Pods', value: 'Dedicated Sprint Engineering Pods', highlight: false },
      { label: 'Flex Hours', value: 'Flexible Rollover Hours Policy', highlight: true },
    ],
    actionIcon: 'support_agent',
  },
];

export function filterSubCategories(categoryId: string): SubCategory[] {
  const filtered = SUBCATEGORIES.filter((sub) => sub.categoryId === categoryId);
  return filtered.length > 0 ? filtered : SUBCATEGORIES.slice(0, 10);
}

export function searchTalent(query: string, items: SubCategory[]): SubCategory[] {
  if (!query || !query.trim()) return items;
  const q = query.toLowerCase().trim();
  return items.filter(
    (item) => item.title.toLowerCase().includes(q) || item.availableCount.toLowerCase().includes(q)
  );
}

export function generateMonaReply(query: string): string {
  const q = query.toLowerCase();
  if (q.includes('rust') || q.includes('system') || q.includes('backend')) {
    return 'I found 14 top-rated Systems & Rust architects currently on active availability with verified cryptographic escrow histories.';
  }
  if (q.includes('escrow') || q.includes('payment') || q.includes('guarantee')) {
    return 'Draft Here escrow utilizes milestone-locked, dual-sign contracts. Funds are only disbursed once deliverables pass your acceptance criteria.';
  }
  if (q.includes('webgl') || q.includes('three') || q.includes('3d') || q.includes('shader')) {
    return 'We have 8 vetted WebGL & Three.js leads available for immediate sprint integration, each with shipped production portfolio pieces.';
  }
  if (q.includes('ai') || q.includes('agent') || q.includes('llm')) {
    return 'Our AI & Automation guild includes specialists in LangChain, autonomous agents, and model fine-tuning with ready-to-deploy enterprise blueprints.';
  }
  return `Thank you for your inquiry about "${query}". I have notified our talent concierge team to calibrate matches within 2 hours.`;
}
