import test from 'node:test';
import assert from 'node:assert/strict';
import { filterSubCategories, searchTalent, generateMonaReply, CATEGORIES, SUBCATEGORIES, MILESTONE_PHASES } from './marketplace';

test('CATEGORIES list contains default categories', () => {
  assert.ok(CATEGORIES.length >= 10);
  assert.equal(CATEGORIES[0].id, 'dev-it');
});

test('SUBCATEGORIES list contains standard entries', () => {
  assert.ok(SUBCATEGORIES.length >= 10);
  const fullStack = SUBCATEGORIES.find((s) => s.id === 'full-stack');
  assert.ok(fullStack);
  assert.equal(fullStack.title, 'Full Stack Developers');
});

test('filterSubCategories returns correct subcategories or fallback', () => {
  const devList = filterSubCategories('dev-it');
  assert.ok(devList.length >= 10);
  assert.equal(devList[0].categoryId, 'dev-it');

  const unknown = filterSubCategories('non-existent');
  assert.ok(unknown.length >= 5);
});

test('searchTalent matches queries accurately', () => {
  const matches = searchTalent('Shopify', SUBCATEGORIES);
  assert.equal(matches.length, 1);
  assert.equal(matches[0].id, 'shopify');

  const emptyMatch = searchTalent('', SUBCATEGORIES);
  assert.equal(emptyMatch.length, SUBCATEGORIES.length);
});

test('generateMonaReply produces calibrated intelligent responses', () => {
  const rustReply = generateMonaReply('Need a Rust backend specialist');
  assert.ok(rustReply.includes('Rust'));

  const escrowReply = generateMonaReply('How does the escrow work?');
  assert.ok(escrowReply.includes('escrow'));

  const genericReply = generateMonaReply('General question');
  assert.ok(genericReply.includes('2 hours'));
});

test('MILESTONE_PHASES contains 6 phases', () => {
  assert.equal(MILESTONE_PHASES.length, 6);
  assert.equal(MILESTONE_PHASES[0].phaseNum, '01');
  assert.equal(MILESTONE_PHASES[5].phaseNum, '06');
});
