/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { ClientMarquee } from './components/ClientMarquee';
import { DomainTaxonomy } from './components/DomainTaxonomy';
import { EnterpriseBanner } from './components/EnterpriseBanner';
import { HowItWorks } from './components/HowItWorks';
import { TestimonialCluster } from './components/TestimonialCluster';
import { Footer } from './components/Footer';
import { MonaChatbot } from './components/MonaChatbot';

export default function App() {
  const [isChatOpen, setIsChatOpen] = useState(false);

  const handleSelectPill = (term: string) => {
    // When a high-demand pill is clicked, scroll smoothly to the domain taxonomy section
    const el = document.getElementById('domain-taxonomy');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="bg-[#fcf9f8] font-['Hanken_Grotesk'] text-[#1c1b1b] antialiased selection:bg-[#590907] selection:text-[#fcf9f8] min-h-screen">
      {/* Sticky Header with Scroll Transition & Category Capsule */}
      <Header
        onOpenConcierge={() => setIsChatOpen(true)}
      />

      {/* Main Content Sections */}
      <main className="w-full pt-16 bg-[#fcf9f8] min-h-[calc(100vh-14rem)]">
        <div className="flex flex-col w-full">
          {/* Editorial Brutalist Hero Section with Dual Kinetic Marquees */}
          <Hero onSelectDemandPill={handleSelectPill} />

          {/* Client Trust Banner with Smooth Horizontal Logo Marquee */}
          <ClientMarquee />

          {/* Domain Taxonomy Section with Liquid Glass & Subcategory Grid */}
          <DomainTaxonomy />

          {/* Deep Cinematic Enterprise Concierge Banner */}
          <EnterpriseBanner onBookBriefing={() => setIsChatOpen(true)} />

          {/* Standard of Engagement / How Draft Here Works (Expanding Milestone Carousel) */}
          <HowItWorks />
        </div>
      </main>

      {/* Client Testimonials & Reviews Section with Interactive Inspection Cluster */}
      <TestimonialCluster />

      {/* Footer with Frosted Trust Guarantee Feature Cards */}
      <Footer />

      {/* Floating AI Concierge Chatbot MONA */}
      <MonaChatbot
        isOpen={isChatOpen}
        onToggle={() => setIsChatOpen((prev) => !prev)}
        onClose={() => setIsChatOpen(false)}
      />
    </div>
  );
}
