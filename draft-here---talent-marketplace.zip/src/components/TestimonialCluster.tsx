import React, { useState, useEffect } from 'react';
import { TestimonialCardData } from '../types';

const TESTIMONIALS: TestimonialCardData[] = [
  // Card 01: Soft Sage / Mint Green
  {
    id: '1',
    number: '№ 01',
    name: 'Liam Vance',
    role: 'VP Product @ Arc Studio',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB5gDTu9cA6PDSmWtfUuytS9cve449e17asSleaaKUfSufdNjhW7bt7daBmhJG1qQsQS3HGzC3o27W30ZbIUK68xHiP_M7-g8yl6IQo-XslEez5t-csx30kv7dvmRAJTkdh2DlAQU7J3kVnZ7soB4SMGcqa46uQqJloSFA0gAbBaOeosIpPaEab2-II3UwaXJgmF4BHvtRhwdTcYn2kPJgsj9Bz-ZQRNpTAZENtmghx',
    stars: 5,
    quote: '“Draft Here matched us with an elite WebGL engineer in 18 hours. The architectural escrow system kept our budget totally secure while delivery exceeded specs.”',
    guild: 'WebGL / Three.js Guild',
    badge: 'Signed & Verified',
    bgColor: 'rgb(226, 228, 214)',
    baseTilt: 'rotate(-5.5deg)',
    hoverTransform: 'translateY(-10px) rotate(-2deg) scale(1.03)',
    positionClasses: 'md:top-2 md:left-6 lg:left-8 z-10',
  },
  // Card 02: Soft Blush / Pastel Rose
  {
    id: '9',
    number: '№ 09',
    name: 'Julian Becker',
    role: 'Managing Director, Pulse Ventures',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCS_f1ZZscNjlGYjztcugPX9AZzUmbiyE9m5GfPkIRcx-rreVKsGt_DRQZSLpXAFe81IJR9pPYSXBPCLCgJStdFLucjgPF4NmJiga-mQ4B_FeG6Y76-xoKaTfBKeN2SixzGYuOCu06Uwquq4V7KjDCHqwGGQQ4OZpLt7NfLrGWEsLJiEz7iUiBcJUhv8YCd1G-dQUOGJKeV7vlUtjY9uvBa9hU4ZlcJn87smGJktuDl',
    stars: 5,
    quote: '“We fund 12 portfolio companies a year; Draft Here is our standard resource to staff technical pods within days without recruitment friction.”',
    guild: 'Venture Cohort',
    badge: 'Tier 1 Client',
    bgColor: 'rgb(255, 218, 213)',
    textColor: 'text-[#360001]',
    subTextColor: 'text-[#812720]',
    baseTilt: 'rotate(5deg)',
    hoverTransform: 'translateY(-10px) rotate(1.5deg) scale(1.03)',
    positionClasses: 'md:top-4 md:right-6 lg:right-8 z-20',
  },
  // Card 03: Crisp Alabaster White
  {
    id: '8',
    number: '№ 08',
    name: 'Maya Lindqvist',
    role: 'Principal, Nordic Design Studio',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDYFoLotslKH9d_839gTrItQ66nAmTOXLoxUJi5j1-b18rOP_G4ADosaCVzHbExSnrH5Oq-aQf0Y8gkmFi6MYRglohivtyPck-3kie1f0uaLlPlI7dtz0ktSgidmMJRl5y9CGAHA0CQ0cFMEojroEz7zkqtD10Pow2LxakKLrj6516eBH17Rq6mT4ThuzOTE4DurZu3I9TIV6ZKOzdwCn2R6NXfNYM2RF5DguBZiCxH',
    stars: 5,
    quote: '“The talent pool here respects typography, grid discipline, and micro-interactions. They speak the exact same language as top design studios.”',
    guild: 'Editorial Typography',
    badge: 'Verified',
    bgColor: 'rgb(255, 255, 255)',
    baseTilt: 'rotate(-2deg)',
    hoverTransform: 'translateY(-10px) rotate(0deg) scale(1.03)',
    positionClasses: 'md:top-16 md:left-1/2 md:-translate-x-1/2 z-30',
  },
  // Card 04: Warm Sand
  {
    id: '12',
    number: '№ 12',
    name: 'Camilla Rossi',
    role: 'Design Director, Hyperion Lab',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCe1E9H8Nw-xKVv5yLW0TnP7Do3WdLw26o0rSb6cwj0AFtCRSLQbzyykk-ymdbE_dZOXCN7nUtnVZB-wLP0HnFTVhKgyE0L_pbmDLZ3uHfAm6_nnDNJzlij_3wRl-NTFlKl3xx1227sO6iNmz4RwR8L2HnQERoNr1Xkso5JdB1v_vpSFhv0rI5cpkMWB5NEtFSHbcYJq5wRbDuE8sijUA0ZZ7gp-lXQ96Xlm9Vc7PTe',
    stars: 5,
    quote: '“Found an elite 3D brand architect in under two hours. The milestone escrow made signoffs effortless and transparent for our leadership.”',
    guild: 'Brand Systems / 3D',
    badge: 'Audited Escrow',
    bgColor: 'rgb(253, 232, 205)',
    baseTilt: 'rotate(3.5deg)',
    hoverTransform: 'translateY(-10px) rotate(0.5deg) scale(1.03)',
    positionClasses: 'md:top-[235px] md:left-2 lg:left-4 z-20',
  },
  // Card 05: Soft Periwinkle
  {
    id: '13',
    number: '№ 13',
    name: 'Darius Chen',
    role: 'CTO, NeuralScale AI',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuH2D5sK7wR9m3yP4xC8v0B6n2M9l3K1j5H6F8D4S8A0Z2X=s160',
    stars: 5,
    quote: '“We secured two senior LangChain / PyTorch contributors who integrated straight into our sprint pipeline. Best contractor experience to date.”',
    guild: 'AI / Agentic Models',
    badge: 'Signed & Verified',
    bgColor: 'rgb(236, 232, 244)',
    baseTilt: 'rotate(-4.5deg)',
    hoverTransform: 'translateY(-10px) rotate(-1.5deg) scale(1.03)',
    positionClasses: 'md:top-[245px] md:right-2 lg:right-4 z-25',
  },
  // Card 06: Oxblood / Burgundy Velvet
  {
    id: '14',
    number: '№ 14',
    name: 'Astrid Lindholm',
    role: 'Head of Product, Veloce Labs',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuF5N9sK3wR1m6yP8xC2v4B7n0M8l6K9j1H8F3D1S7A1Z4X=s160',
    stars: 5,
    quote: '“Zero fluff, no junior handoffs. The senior engineers on Draft Here build enterprise-grade software that actually ships on schedule.”',
    guild: 'Full Stack Next.js',
    badge: 'Tier 1 Client',
    bgColor: 'rgb(89, 9, 7)',
    textColor: 'text-white',
    subTextColor: 'text-[#ffdad5]',
    baseTilt: 'rotate(3deg)',
    hoverTransform: 'translateY(-10px) rotate(0.5deg) scale(1.03)',
    positionClasses: 'md:top-[345px] md:left-1/2 md:-translate-x-1/2 z-28',
  },
  // Card 07: Crisp Neo-Editorial Alabaster
  {
    id: '15',
    number: '№ 15',
    name: 'Kenji Sato',
    role: 'Creative Technologist, Mono Studio',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuJ3M6kP8wR2t5yP9xC1v7B4n0M7l1K8j4H9F2D0S1A3Z7X=s160',
    stars: 5,
    quote: '“Dual-sign IP protection and instant escrow disbursement gave both our team and the freelance lead total peace of mind.”',
    guild: 'Creative Technologist',
    badge: 'Escrow Signed',
    bgColor: 'rgb(255, 255, 255)',
    baseTilt: 'rotate(-3deg)',
    hoverTransform: 'translateY(-10px) rotate(-0.5deg) scale(1.03)',
    positionClasses: 'md:top-[440px] md:right-8 lg:right-14 z-15',
  },
  // Card 08: Dark Obsidian
  {
    id: '10',
    number: '№ 10',
    name: 'Tariq Mansoor',
    role: 'Lead Architect, Quantik',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuK8P1wR4m0t7yP2xC6v5B8n1M4l0K7j2H5F0D9S3A5Z8X=s160',
    stars: 5,
    quote: '“Milestone-based fund release kept our contracts airtight. The platform mediated technical definitions with surgical accuracy.”',
    guild: 'Rust / Systems',
    badge: 'Verified',
    bgColor: 'rgb(28, 27, 27)',
    textColor: 'text-white',
    subTextColor: 'text-[#ebe7e7]/75',
    baseTilt: 'rotate(-4.5deg)',
    hoverTransform: 'translateY(-10px) rotate(-1deg) scale(1.03)',
    positionClasses: 'md:bottom-3 md:left-6 lg:left-10 z-20',
  },
  // Card 09: Deep Charcoal
  {
    id: '11',
    number: '№ 11',
    name: 'Zoe Katsaros',
    role: 'Head of Growth, Solstice',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuF5N9sK3wR1m6yP8xC2v4B7n0M8l6K9j1H8F3D1S7A1Z4X=s160',
    stars: 5,
    quote: '“No recruiter markups or hidden fees. We hired two world-class full stack creators on ongoing retainers. Absolute game changer.”',
    guild: 'Enterprise Retainer',
    badge: 'Signed Release',
    bgColor: 'rgb(37, 36, 35)',
    textColor: 'text-white',
    subTextColor: 'text-[#ffdad5]',
    baseTilt: 'rotate(4.5deg)',
    hoverTransform: 'translateY(-10px) rotate(1.5deg) scale(1.03)',
    positionClasses: 'md:bottom-2 md:right-4 lg:right-8 z-25',
  },
  // Card 10: Soft Periwinkle Blue
  {
    id: '16',
    number: '№ 07',
    name: 'Elena Rostova',
    role: 'Chief Brand Officer, Kinetix',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuF5N9sK3wR1m6yP8xC2v4B7n0M8l6K9j1H8F3D1S7A1Z4X=s160',
    stars: 5,
    quote: '“Commissioned an entire brand system with custom typography guidelines. The design direction surpassed our internal team\'s highest standards.”',
    guild: 'Creative Direction',
    badge: 'Signed Release',
    bgColor: '#e8edf9',
    baseTilt: 'rotate(-6deg)',
    hoverTransform: 'translateY(-10px) rotate(-1deg) scale(1.03)',
    positionClasses: 'md:top-[125px] md:left-[12%] lg:left-[14%] z-22',
  },
  // Card 11: Muted Celadon
  {
    id: '17',
    number: '№ 17',
    name: 'Marcus Thorne',
    role: 'VP Engineering, Synapse Labs',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuK8P1wR4m0t7yP2xC6v5B8n1M4l0K7j2H5F0D9S3A5Z8X=s160',
    stars: 5,
    quote: '“Their automated evaluation process found us a specialized fine-tuning architect within hours. Milestones were met with zero friction.”',
    guild: 'AI Pipelines & LLMs',
    badge: 'Escrow Verified',
    bgColor: '#e2edd8',
    baseTilt: 'rotate(6.5deg)',
    hoverTransform: 'translateY(-10px) rotate(1deg) scale(1.03)',
    positionClasses: 'md:top-[135px] md:right-[11%] lg:right-[13%] z-22',
  },
  // Card 12: Warm Buttercream
  {
    id: '18',
    number: '№ 18',
    name: 'Siddharth Patel',
    role: 'Product Lead, Omniflow',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCQQqPKBg7tKd5LDnGh3aFNcm9eFHXOn8W2Gy2ou3wiO5e7OxCMz92_gpax_4suj__fHqk9VQ6HNRic62yX1HFUeORT7C8ly21ooRCmfzURw9kDvRZ5q50TsmAeDD809gNlFuK8qsvC55zu_FJQAQ_Xt8iM4kAYqkSkZV2tC5UmZPL9f-XBECkoQpY678Rqyo4eW9d6XFyWJPIWKhAMSmANuCCPvD4o6smFgA04l0TF',
    stars: 5,
    quote: '“The escrow and dual-sign protocol give enterprise founders true peace of mind. Highest code quality we’ve seen in any marketplace.”',
    guild: 'Systems Architecture',
    badge: 'Tier 1 Client',
    bgColor: '#fdf4d9',
    baseTilt: 'rotate(-3.5deg)',
    hoverTransform: 'translateY(-10px) rotate(0deg) scale(1.03)',
    positionClasses: 'md:top-[515px] md:left-[10%] lg:left-[12%] z-20',
  },
  // Card 13: Deep Graphite Slate
  {
    id: '19',
    number: '№ 19',
    name: 'Clara Vane',
    role: 'Executive Producer, Apex Motion',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuJ3M6kP8wR2t5yP9xC1v7B4n0M7l1K8j4H9F2D0S1A3Z7X=s160',
    stars: 5,
    quote: '“Seamless collaboration from raw storyboards to WebGL rendering. Draft Here has solved the quality gap for elite independent talent.”',
    guild: 'Motion & 3D Systems',
    badge: 'Verified',
    bgColor: 'rgb(32, 31, 30)',
    textColor: 'text-white',
    subTextColor: 'text-[#f6dfc2]',
    baseTilt: 'rotate(4deg)',
    hoverTransform: 'translateY(-10px) rotate(0.5deg) scale(1.03)',
    positionClasses: 'md:top-[535px] md:left-1/2 md:-translate-x-1/2 z-26',
  },
  // Card 14: Warm Terracotta Ochre
  {
    id: '20',
    number: '№ 04',
    name: 'Arlo Thorne',
    role: 'Design Engineer, Framework',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDF_e2_h8T49R51uMh-z5W2gM0xP74g-s7mDqX1Y7e4fB0Mh_9A8x8KqK0XyQ=s160',
    stars: 5,
    quote: '“Found a GLSL shader engineer who rebuilt our marketing site hero in 3 days. Clean handover, flawless frame pacing, zero friction.”',
    guild: 'Shader Dev / GLSL',
    badge: 'Escrow Verified',
    bgColor: '#fde8cd',
    baseTilt: 'rotate(-3.5deg)',
    hoverTransform: 'translateY(-10px) rotate(-0.5deg) scale(1.03)',
    positionClasses: 'md:top-[235px] md:left-1/2 md:-translate-x-1/2 z-26',
  },
  // Card 15: Soft Pastel Sage
  {
    id: '21',
    number: '№ 21',
    name: 'Soren Møller',
    role: 'Head of AI Ops, Aethel Labs',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBFXLwSY2t6exzY3kZ03Inco9HYHj-HPYQOBcwByuO8fjNfvxHd9gad9wHA2z0bArsjbOmGAuviOUcParkX1b3ZRxvnxQtqzfpwfNTW1bFhPb5v7ddxINctUrsrjm7vB9K8H7zs-BNjMzDSwtWIh5vmyL7PaDZ-MjZ2CP6VlegdmSnbAgCp4dNRlF5RfBA0LNVTO2mZ4E52kE9EeS3H0S5NTpVh_3xGyU7TxqbwChWu',
    stars: 5,
    quote: '“Draft Here replaced a months-long search for agentic RAG specialists. Our contracts were deployed and verified in record time.”',
    guild: 'Retrieval AI / RAG',
    badge: 'Signed Release',
    bgColor: '#d4f4cd',
    baseTilt: 'rotate(5.5deg)',
    hoverTransform: 'translateY(-10px) rotate(1deg) scale(1.03)',
    positionClasses: 'md:top-[440px] md:left-[24%] z-25',
  },
  // Card 16: Pastel Blush Rose
  {
    id: '22',
    number: '№ 16',
    name: 'Nadia Vos',
    role: 'VP Creative, Monolith Agency',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuF5N9sK3wR1m6yP8xC2v4B7n0M8l6K9j1H8F3D1S7A1Z4X=s160',
    stars: 5,
    quote: '“Card-sharp execution on our dynamic design tokens and kinetic micro-interactions. The top 1% promise is genuinely authentic.”',
    guild: 'Kinetic UI Systems',
    badge: 'Audited Escrow',
    bgColor: '#ffd5dc',
    textColor: 'text-[#360001]',
    subTextColor: 'text-[#812720]',
    baseTilt: 'rotate(-4.5deg)',
    hoverTransform: 'translateY(-10px) rotate(-1deg) scale(1.03)',
    positionClasses: 'md:top-[185px] md:right-[26%] z-23',
  },
  // Card 17: Buttercream Vanilla Ochre
  {
    id: '23',
    number: '№ 22',
    name: 'Matteo Ricci',
    role: 'Design Partner, Studio Velo',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCDCVSrj7c7QYxbeQsw3SXJHK-B5G1L3PkzoJ88HKfarcVpyXfypM-ZiCvj7YALRc5jv5AZFJ9u8LgEREqwSNxsiON3v2kYINJImrdDR-jquvRrz_FIX6e96rTw_Bre22GCDTwgRmPdeCuyCm572xuELr_87SBtmcdHuq_eOSo_NjMVTD8oPMxtBFpb_UlENJ1jQVYfdCnHTP3m9i6xVqwgQ106zfono50Y4bbNpZcg',
    stars: 5,
    quote: '“Draft Here makes contracting creative leads effortless. Milestone disbursements are transparent and instant upon sprint signoff.”',
    guild: 'Motion Branding',
    badge: 'Tier 1 Client',
    bgColor: 'rgb(254, 247, 220)',
    baseTilt: 'rotate(-2.5deg)',
    hoverTransform: 'translateY(-10px) rotate(0deg) scale(1.03)',
    positionClasses: 'md:bottom-3 md:left-1/2 md:-translate-x-1/2 z-27',
  },
];

export const TestimonialCluster: React.FC = () => {
  const [inspectedId, setInspectedId] = useState<string | null>(null);

  const handleCardClick = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setInspectedId((prev) => (prev === id ? null : id));
  };

  useEffect(() => {
    const handleGlobalClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest('.sticker-card')) {
        setInspectedId(null);
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setInspectedId(null);
      }
    };

    document.addEventListener('click', handleGlobalClick);
    document.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('click', handleGlobalClick);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  return (
    <section
      className="w-full px-4 sm:px-6 lg:px-12 py-20 bg-[#fcf9f8] relative overflow-hidden border-t border-black/10"
      id="testimonials-section"
    >
      <div className="max-w-[1520px] mx-auto relative z-10 px-2 sm:px-6">
        {/* Section Header */}
        <div className="flex flex-col items-center text-center mb-10 sm:mb-14">
          <h2 className="font-['Space_Grotesk'] text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#1c1b1b] mb-3">
            What They Say?
          </h2>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-white border border-black/10 shadow-sm text-[#1c1b1b] font-['Space_Grotesk'] text-[11px] font-semibold tracking-wider uppercase">
              <span className="w-2 h-2 rounded-full bg-[#10b981] animate-ping"></span>
              <span>● CLICK CARD TO INSPECT</span>
            </div>
            <span className="text-[#56423f] text-[12px] font-['Space_Grotesk'] tracking-wide">
              340+ Verified Reviews
            </span>
          </div>
        </div>

        {/* Decorative 4-Pointed Sparkle Star Accents */}
        <div className="relative w-full max-w-6xl mx-auto py-4">
          <div className="absolute -top-6 left-6 text-[#ba1a1a] pointer-events-none z-20 sparkle-icon hidden md:block">
            <svg className="w-8 h-8" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 0L14.5 9.5L24 12L14.5 14.5L12 24L9.5 14.5L0 12L9.5 9.5L12 0Z" />
            </svg>
          </div>
          <div
            className="absolute top-1/4 -right-2 text-[#590907] pointer-events-none z-20 sparkle-icon hidden md:block"
            style={{ animationDelay: '1.5s' }}
          >
            <svg className="w-7 h-7" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 0L14.5 9.5L24 12L14.5 14.5L12 24L9.5 14.5L0 12L9.5 9.5L12 0Z" />
            </svg>
          </div>
          <div
            className="absolute bottom-12 -left-3 text-[#1c1b1b] pointer-events-none z-20 sparkle-icon hidden md:block"
            style={{ animationDelay: '2.5s' }}
          >
            <svg className="w-6 h-6" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 0L14.5 9.5L24 12L14.5 14.5L12 24L9.5 14.5L0 12L9.5 9.5L12 0Z" />
            </svg>
          </div>
          <div
            className="absolute -bottom-4 right-1/4 text-[#ba1a1a] pointer-events-none z-20 sparkle-icon hidden md:block"
            style={{ animationDelay: '0.8s' }}
          >
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 0L14.5 9.5L24 12L14.5 14.5L12 24L9.5 14.5L0 12L9.5 9.5L12 0Z" />
            </svg>
          </div>

          {/* Testimonial Sticker Canvas */}
          <div
            id="testimonialCluster"
            className={`testimonial-sticker-canvas relative flex flex-col md:block w-full max-w-[1160px] mx-auto min-h-[820px] md:h-[840px] pb-8 md:pb-0 ${
              inspectedId ? 'has-inspected' : ''
            }`}
          >
            {TESTIMONIALS.map((card) => {
              const isInspected = inspectedId === card.id;
              const textColorClass = card.textColor || 'text-[#1c1b1b]';
              const subTextColorClass = card.subTextColor || 'text-[#56423f]';
              const isDarkCard = card.textColor === 'text-white';

              return (
                <div
                  key={card.id}
                  data-card-id={card.id}
                  className={`sticker-card md:absolute md:w-[340px] lg:w-[365px] rounded-3xl p-6 border-2 border-[#1c1b1b] flex flex-col justify-between shadow-[8px_8px_0px_#1c1b1b] mb-6 md:mb-0 ${
                    card.positionClasses
                  } ${isInspected ? 'is-inspected' : ''}`}
                  style={
                    {
                      backgroundColor: card.bgColor,
                      '--base-tilt': card.baseTilt,
                      '--hover-transform': card.hoverTransform,
                      transform: isInspected
                        ? 'translate3d(0, -14px, 0) rotate(0deg) scale(1.06)'
                        : card.baseTilt,
                    } as React.CSSProperties
                  }
                  onClick={(e) => handleCardClick(card.id, e)}
                >
                  <div className={`flex items-center justify-between mb-4 border-b ${isDarkCard ? 'border-white/20' : 'border-black/10'} pb-3`}>
                    <div className="flex items-center gap-2.5">
                      <img
                        src={card.avatar}
                        alt={card.name}
                        className={`w-10 h-10 rounded-full object-cover border ${isDarkCard ? 'border-white/25' : 'border-black/10'} shrink-0 shadow-sm`}
                        onError={(e) => {
                          e.currentTarget.onerror = null;
                          e.currentTarget.src =
                            'https://lh3.googleusercontent.com/aida-public/AB6AXuB5gDTu9cA6PDSmWtfUuytS9cve449e17asSleaaKUfSufdNjhW7bt7daBmhJG1qQsQS3HGzC3o27W30ZbIUK68xHiP_M7-g8yl6IQo-XslEez5t-csx30kv7dvmRAJTkdh2DlAQU7J3kVnZ7soB4SMGcqa46uQqJloSFA0gAbBaOeosIpPaEab2-II3UwaXJgmF4BHvtRhwdTcYn2kPJgsj9Bz-ZQRNpTAZENtmghx';
                        }}
                      />
                      <div>
                        <div className={`font-['Space_Grotesk'] font-bold text-[15px] leading-tight ${textColorClass}`}>
                          {card.name}
                        </div>
                        <div className={`font-['Hanken_Grotesk'] text-[11px] ${subTextColorClass}`}>
                          {card.role}
                        </div>
                      </div>
                    </div>
                    <span
                      className={`font-['Space_Grotesk'] text-[11px] font-mono font-bold ${
                        isDarkCard ? 'text-[#f6dfc2] bg-white/10' : 'text-[#1c1b1b] bg-black/10'
                      } px-2.5 py-0.5 rounded-full`}
                    >
                      {card.number}
                    </span>
                  </div>

                  <div className={`flex items-center gap-1 ${isDarkCard ? 'text-[#f6dfc2]' : 'text-[#ba1a1a]'} mb-2.5 text-[15px]`}>
                    {'★'.repeat(card.stars)}
                  </div>

                  <p className={`font-['Hanken_Grotesk'] text-[13.5px] leading-relaxed mb-5 ${isDarkCard ? 'text-[#ebe7e7] font-light' : `${textColorClass} font-normal`}`}>
                    {card.quote}
                  </p>

                  <div className={`flex items-center justify-between text-[11px] font-['Space_Grotesk'] pt-3 border-t ${isDarkCard ? 'border-white/20 text-[#f6dfc2]' : 'border-black/10 text-[#56423f]'}`}>
                    <span className={`font-bold uppercase tracking-wider ${isDarkCard ? 'text-[#f6dfc2]' : 'text-[#360001]'}`}>
                      {card.guild}
                    </span>
                    <span className="font-medium">{card.badge}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Centered Bottom URL Indicator */}
        <div className="flex justify-center items-center mt-8 pt-6 border-t border-black/10">
          <a
            href="#"
            className="font-['Space_Grotesk'] text-[14px] sm:text-[15px] font-bold text-[#1c1b1b] tracking-[0.14em] uppercase hover:text-[#590907] transition-colors wavy-accent-line"
          >
            draft-here
          </a>
        </div>
      </div>
    </section>
  );
};
