import React from 'react';

const LOGOS = [
  { name: 'airbnb', className: "font-['Space_Grotesk'] text-lg font-semibold tracking-tighter text-on-surface hover:text-[#1c1b1b] hover:opacity-100 transition-all cursor-pointer" },
  { name: 'databricks', className: "font-['Space_Grotesk'] text-lg font-semibold tracking-tight text-on-surface hover:text-[#1c1b1b] hover:opacity-100 transition-all cursor-pointer" },
  { name: 'cloudflare', className: "font-['Space_Grotesk'] text-lg font-semibold tracking-tight text-on-surface hover:text-[#1c1b1b] hover:opacity-100 transition-all cursor-pointer" },
  { name: 's c a l e', className: "font-['Space_Grotesk'] text-lg font-semibold tracking-normal text-on-surface hover:text-[#1c1b1b] hover:opacity-100 transition-all cursor-pointer" },
  { name: 'stripe', className: "font-['Space_Grotesk'] text-lg font-bold tracking-tight text-on-surface hover:text-[#1c1b1b] hover:opacity-100 transition-all cursor-pointer" },
  { name: 'Microsoft', className: "font-['Space_Grotesk'] text-lg font-medium tracking-tight text-on-surface hover:text-[#1c1b1b] hover:opacity-100 transition-all cursor-pointer" },
  { name: 'Figma', className: "font-['Space_Grotesk'] text-lg font-bold tracking-tight text-on-surface hover:text-[#1c1b1b] hover:opacity-100 transition-all cursor-pointer" },
  { name: 'grammarly', className: "font-['Space_Grotesk'] text-lg font-bold tracking-tight text-on-surface hover:text-[#1c1b1b] hover:opacity-100 transition-all cursor-pointer" },
  { name: 'Notion', className: "font-['Space_Grotesk'] text-lg font-semibold tracking-tight text-on-surface hover:text-[#1c1b1b] hover:opacity-100 transition-all cursor-pointer" },
  { name: 'LINEAR', className: "font-['Space_Grotesk'] text-lg font-semibold tracking-wide text-on-surface hover:text-[#1c1b1b] hover:opacity-100 transition-all cursor-pointer" },
  { name: 'Spotify', className: "font-['Space_Grotesk'] text-lg font-bold tracking-tight text-on-surface hover:text-[#1c1b1b] hover:opacity-100 transition-all cursor-pointer" },
  { name: 'bambooHR', className: "font-['Space_Grotesk'] text-lg font-normal tracking-wide text-on-surface hover:text-[#1c1b1b] hover:opacity-100 transition-all cursor-pointer", isBamboo: true },
  { name: '▲ Vercel', className: "font-['Space_Grotesk'] text-lg font-bold tracking-tight text-on-surface hover:text-[#1c1b1b] hover:opacity-100 transition-all cursor-pointer" },
  { name: 'retool', className: "font-['Space_Grotesk'] text-lg font-bold tracking-wider text-on-surface hover:text-[#1c1b1b] hover:opacity-100 transition-all cursor-pointer" },
  { name: 'shutterstock', className: "font-['Space_Grotesk'] text-lg font-semibold tracking-tighter text-on-surface hover:text-[#1c1b1b] hover:opacity-100 transition-all cursor-pointer" },
  { name: 'OpenAI', className: "font-['Space_Grotesk'] text-lg font-bold tracking-tight text-on-surface hover:text-[#1c1b1b] hover:opacity-100 transition-all cursor-pointer" },
];

export const ClientMarquee: React.FC = () => {
  return (
    <section className="w-full bg-[#f6f3f2] py-8 px-6 lg:px-12 shadow-[inset_0_1px_0_rgba(18,18,18,0.04)]">
      <div className="max-w-7xl mx-auto flex flex-col items-center">
        <p className="font-['Space_Grotesk'] text-[11px] uppercase tracking-widest text-[#5d5f55] mb-6 text-center font-semibold">
          Trusted by 800,000+ scaling teams and high-growth venture studios
        </p>
        <div className="client-marquee-container w-full overflow-hidden select-none relative opacity-70 grayscale contrast-125 [mask-image:linear-gradient(to_right,transparent_0%,black_8%,black_92%,transparent_100%)] [-webkit-mask-image:linear-gradient(to_right,transparent_0%,black_8%,black_92%,transparent_100%)]">
          <div
            className="client-marquee-track flex items-center gap-12 sm:gap-16 lg:gap-20 whitespace-nowrap will-change-transform"
            style={{
              display: 'flex',
              width: 'max-content',
              animation: 'clientMarquee 28s linear infinite',
            }}
          >
            {/* Loop 1 */}
            <div className="flex items-center gap-12 sm:gap-16 lg:gap-20 flex-shrink-0">
              {LOGOS.map((item, idx) => (
                <div key={`logo-1-${idx}`} className={item.className}>
                  {item.isBamboo ? (
                    <>bamboo<span className="font-bold">HR</span></>
                  ) : (
                    item.name
                  )}
                </div>
              ))}
            </div>

            {/* Loop 2 (Duplicate for infinite seamless glide) */}
            <div aria-hidden="true" className="flex items-center gap-12 sm:gap-16 lg:gap-20 flex-shrink-0">
              {LOGOS.map((item, idx) => (
                <div key={`logo-2-${idx}`} className={item.className}>
                  {item.isBamboo ? (
                    <>bamboo<span className="font-bold">HR</span></>
                  ) : (
                    item.name
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
