import React, { useEffect, useState } from 'react';

interface HeaderProps {
  onSearchFocus?: () => void;
  onOpenConcierge?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onSearchFocus, onOpenConcierge }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [searchValue, setSearchValue] = useState('');

  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY || document.documentElement.scrollTop;
      const scrolled = scrollY > 70;
      setIsScrolled(scrolled);
      if (scrolled) {
        document.body.classList.add('is-scrolled');
      } else {
        document.body.classList.remove('is-scrolled');
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    window.addEventListener('resize', handleScroll);
    document.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();

    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('resize', handleScroll);
      document.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <header
      className="fixed top-0 left-0 right-0 w-full z-50 bg-[#fcf9f8]/90 backdrop-blur-md border-b border-black/10 shadow-[0_1px_8px_rgba(0,0,0,0.03)] transition-all duration-300"
      id="mainHeader"
    >
      <div className="w-full">
        <div className="max-w-[1520px] mx-auto px-6 lg:px-12 py-2.5 flex items-center justify-between gap-6 relative min-h-[58px]">
          {/* Logo */}
          <div className="flex items-center gap-8 min-w-0 z-20">
            <a className="flex items-center flex-shrink-0 mr-1" href="#">
              <img
                alt="Draft Here"
                className="w-auto object-contain h-12"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuBAgTyA3iAadG0g9oN0wXXn6rMMgZSGzVhYVRuIwjgdqd-HXMcG-KbjNKgL_RmfAvj5FKcEQowgBBb7bB1AeA8cYv1se6oQ3gCaSTvsuMVPkU_XQSFO3zTSqbm6AnFqczxYvQiGreYfWcJnHymX5IkcoHhXNfXaNvRz93dfqKkFd0Jii1mFBjffhxw-Wqp-gCTTkSD_Hmugh5n42gXgGIp_CgrcPIh2ydExRt-ZzxZljnGuQ8m2xjWF-A"
              />
            </a>
          </div>

          {/* Center Navigation Container with Smooth Transition */}
          <div className="flex-1 flex items-center justify-center min-w-0 relative h-11">
            {/* Primary Nav Slot (Visible at top) */}
            <div
              className={`flex items-center justify-center gap-3 w-full max-w-2xl transition-all duration-400 absolute inset-0 my-auto ${
                isScrolled
                  ? 'opacity-0 pointer-events-none -translate-y-2 scale-95'
                  : 'opacity-100 pointer-events-auto translate-y-0 scale-100'
              }`}
              id="primary-nav-slot"
            >
              <nav aria-label="Main Navigation" className="hidden lg:flex items-center gap-1.5 p-1 bg-[#f6f3f2]/70 rounded-full border border-black/5">
                <a
                  className="px-3.5 py-1.5 rounded-full bg-[#590907]/10 text-[#590907] font-['Space_Grotesk'] text-[13px] font-semibold transition-all whitespace-nowrap flex-shrink-0"
                  href="#"
                >
                  Home
                </a>
                <a
                  className="px-3 py-1.5 rounded-full text-[#56423f] hover:text-[#1c1b1b] hover:bg-black/5 font-['Space_Grotesk'] text-[13px] font-medium transition-all whitespace-nowrap flex-shrink-0"
                  href="#domain-taxonomy"
                >
                  Dev &amp; IT
                </a>
                <a
                  className="px-3 py-1.5 rounded-full text-[#56423f] hover:text-[#1c1b1b] hover:bg-black/5 font-['Space_Grotesk'] text-[13px] font-medium transition-all whitespace-nowrap flex-shrink-0"
                  href="#domain-taxonomy"
                >
                  AI &amp; Automation
                </a>
                <a
                  className="px-3 py-1.5 rounded-full text-[#56423f] hover:text-[#1c1b1b] hover:bg-black/5 font-['Space_Grotesk'] text-[13px] font-medium transition-all whitespace-nowrap flex-shrink-0"
                  href="#domain-taxonomy"
                >
                  Design
                </a>
                <a
                  className="px-3 py-1.5 rounded-full text-[#56423f] hover:text-[#1c1b1b] hover:bg-black/5 font-['Space_Grotesk'] text-[13px] font-medium transition-all whitespace-nowrap flex-shrink-0"
                  href="#domain-taxonomy"
                >
                  Marketing
                </a>
                <a
                  className="px-3.5 py-1.5 rounded-full text-[#56423f] hover:text-[#1c1b1b] hover:bg-black/5 font-['Space_Grotesk'] text-[13px] font-medium transition-all whitespace-nowrap flex-shrink-0"
                  href="#"
                >
                  Enterprise
                </a>
              </nav>

              <div className="hidden md:flex items-center w-56 lg:w-64">
                <div className="w-full flex items-center h-9 bg-white/90 rounded-full border border-black/15 px-3 shadow-[0_1px_4px_rgba(0,0,0,0.02)] focus-within:border-[#1c1b1b] transition-colors">
                  <span className="material-symbols-outlined text-[18px] text-[#56423f] mr-2 flex-shrink-0">
                    search
                  </span>
                  <input
                    aria-label="Search verified architects"
                    className="w-full bg-transparent border-0 focus:outline-none font-['Hanken_Grotesk'] text-[12px] text-[#1c1b1b] placeholder:text-[#56423f]/70 min-w-0"
                    placeholder="Search verified architects..."
                    type="text"
                    value={searchValue}
                    onChange={(e) => setSearchValue(e.target.value)}
                    onFocus={onSearchFocus}
                  />
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-mono uppercase bg-[#f0edec] text-[#56423f] border border-black/5 flex-shrink-0 ml-1">
                    ⌘K
                  </span>
                </div>
              </div>
            </div>

            {/* Category Nav Slot (Visible on Scroll) */}
            <div
              className={`flex items-center justify-center w-full h-full transition-all duration-400 absolute inset-0 my-auto pointer-events-none ${
                isScrolled ? 'opacity-100 pointer-events-auto' : 'opacity-0'
              }`}
              id="category-nav-slot"
            >
              <div className="category-capsule-wrapper relative flex items-center justify-center max-w-full">
                <div
                  className="category-capsule flex items-center justify-center text-white px-2 py-1 rounded-full border border-white/15 select-none gap-1 sm:gap-1.5 shadow-2xl bg-[#16161a]/95 backdrop-blur-xl whitespace-nowrap"
                  id="categoryCapsule"
                >
                  <nav aria-label="Category Navigation" className="flex items-center gap-0.5 sm:gap-1 flex-shrink-0">
                    <a
                      className="relative px-2.5 py-1 rounded-full text-white font-['Space_Grotesk'] text-[11px] font-bold uppercase tracking-wider flex items-center gap-1.5 bg-white/15 border border-white/20 shadow-sm transition-all flex-shrink-0 whitespace-nowrap"
                      href="#domain-taxonomy"
                      title="Dev & IT"
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-[#10b981] animate-pulse"></span>
                      <span className="material-symbols-outlined text-[15px] text-[#10b981]">code</span>
                      <span className="whitespace-nowrap">Dev &amp; IT</span>
                    </a>
                    <a
                      className="relative px-2 py-1 rounded-full text-white/70 hover:text-white flex items-center gap-1 hover:bg-white/10 font-['Space_Grotesk'] text-[11px] font-medium transition-all flex-shrink-0 whitespace-nowrap group"
                      href="#domain-taxonomy"
                      title="AI & Automation"
                    >
                      <span className="material-symbols-outlined text-[15px] group-hover:scale-110 transition-transform">
                        smart_toy
                      </span>
                      <span className="hidden xl:inline whitespace-nowrap">AI &amp; Automation</span>
                      <span className="hidden md:inline xl:hidden whitespace-nowrap">AI</span>
                    </a>
                    <a
                      className="relative px-2 py-1 rounded-full text-white/70 hover:text-white flex items-center gap-1 hover:bg-white/10 font-['Space_Grotesk'] text-[11px] font-medium transition-all flex-shrink-0 whitespace-nowrap group"
                      href="#domain-taxonomy"
                      title="Design & Creative"
                    >
                      <span className="material-symbols-outlined text-[15px] group-hover:scale-110 transition-transform">
                        palette
                      </span>
                      <span className="hidden md:inline whitespace-nowrap">Design</span>
                    </a>
                    <a
                      className="relative px-2 py-1 rounded-full text-white/70 hover:text-white flex items-center gap-1 hover:bg-white/10 font-['Space_Grotesk'] text-[11px] font-medium transition-all flex-shrink-0 whitespace-nowrap group"
                      href="#domain-taxonomy"
                      title="Marketing"
                    >
                      <span className="material-symbols-outlined text-[15px] group-hover:scale-110 transition-transform">
                        campaign
                      </span>
                      <span className="hidden lg:inline whitespace-nowrap">Marketing</span>
                    </a>
                    <a
                      className="relative px-2 py-1 rounded-full text-white/70 hover:text-white hidden xl:flex items-center gap-1 hover:bg-white/10 font-['Space_Grotesk'] text-[11px] font-medium transition-all flex-shrink-0 whitespace-nowrap group"
                      href="#domain-taxonomy"
                      title="Writing"
                    >
                      <span className="material-symbols-outlined text-[15px] group-hover:scale-110 transition-transform">
                        edit_note
                      </span>
                      <span className="whitespace-nowrap">Writing</span>
                    </a>
                  </nav>

                  <div className="w-[1px] h-3.5 bg-white/20 mx-0.5 flex-shrink-0" />

                  <div className="flex items-center flex-shrink-0">
                    <a
                      className="quick-nav-pill px-2.5 py-1 rounded-full bg-white/10 hover:bg-white/15 text-white/95 font-['Space_Grotesk'] text-[10.5px] font-semibold tracking-wider flex items-center gap-1 border border-white/15 transition-all whitespace-nowrap"
                      href="#domain-taxonomy"
                    >
                      <span className="material-symbols-outlined text-[13px] text-[#f6dfc2]">verified</span>
                      <span>Top 1%</span>
                    </a>
                  </div>

                  <div className="flex items-center flex-shrink-0 pl-0.5">
                    <button
                      className="px-2.5 py-1 rounded-full bg-white text-[#1c1b1b] font-['Space_Grotesk'] text-[10.5px] font-bold uppercase tracking-wider hover:bg-[#f0edec] hover:scale-105 active:scale-95 transition-all flex items-center gap-1 shadow-sm whitespace-nowrap flex-shrink-0 cursor-pointer"
                      onClick={onOpenConcierge}
                      title="Concierge Direct Dispatch"
                      type="button"
                    >
                      <span className="material-symbols-outlined text-[13px] text-[#590907]">support_agent</span>
                      <span>Concierge</span>
                      <span className="w-1.5 h-1.5 rounded-full bg-[#10b981]"></span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Header Controls */}
          <div className="flex items-center gap-4 flex-shrink-0 z-20">
            <a
              className={`font-['Space_Grotesk'] text-[11px] font-semibold uppercase tracking-[0.14em] text-[#56423f] hover:text-[#1c1b1b] transition-colors px-3 py-1.5 rounded-full hover:bg-black/5 ${
                isScrolled ? 'hidden 2xl:inline-block' : 'hidden xl:inline-block'
              }`}
              href="#"
            >
              Become a Seller
            </a>
            <div className="flex items-center gap-2 pl-2 border-l border-black/10">
              <button
                aria-label="Notifications"
                className="p-2 rounded-full text-[#56423f] hover:text-[#1c1b1b] hover:bg-black/5 transition-colors relative"
                type="button"
              >
                <span className="material-symbols-outlined text-[20px]">notifications</span>
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#ba1a1a]"></span>
              </button>
              <a
                className="px-5 py-1.5 rounded-full border border-black/20 hover:border-black text-[#1c1b1b] hover:bg-black/5 font-['Space_Grotesk'] text-[12px] font-semibold tracking-wide transition-all"
                href="#"
              >
                Log In
              </a>
              <a
                className="hidden sm:inline-flex px-4 py-1.5 rounded-full bg-[#1c1b1b] text-[#fcf9f8] hover:bg-[#590907] font-['Space_Grotesk'] text-[12px] font-bold tracking-wide transition-all shadow-sm items-center justify-center"
                href="#"
              >
                Get Started
              </a>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
