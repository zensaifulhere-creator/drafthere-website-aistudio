import React, { useState } from 'react';

interface HeroProps {
  onSearch?: (query: string) => void;
  onSelectDemandPill?: (term: string) => void;
}

export const Hero: React.FC<HeroProps> = ({ onSearch, onSelectDemandPill }) => {
  const [query, setQuery] = useState('');

  const handleSearchSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (onSearch) onSearch(query);
    const domainSection = document.getElementById('domain-taxonomy');
    if (domainSection) {
      domainSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handlePillClick = (term: string) => {
    setQuery(term);
    if (onSelectDemandPill) onSelectDemandPill(term);
    const domainSection = document.getElementById('domain-taxonomy');
    if (domainSection) {
      domainSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative w-full bg-[#FCF9F8] overflow-hidden pt-6 pb-12 border-b border-black/10" id="heroSection">
      <div className="w-full max-w-[1520px] mx-auto px-4 sm:px-6 lg:px-12 relative">
        {/* Top Editorial Status Row */}
        <div className="flex items-center justify-between border-b border-black/10 pb-4 mb-4 font-['Space_Grotesk'] text-[11px] uppercase tracking-[0.22em] text-[#1c1b1b]">
          <div className="flex flex-col sm:flex-row sm:items-center sm:gap-4">
            <span className="font-bold text-[#1c1b1b] tracking-[0.25em]">DRAFT HERE / STUDIO</span>
            <span className="text-[#56423f] tracking-[0.18em] text-[10px]">COHORT № 24 · VERIFIED</span>
          </div>
          <div className="hidden sm:flex items-center gap-2 text-[#56423f] text-[10px] tracking-[0.18em]">
            <span className="w-2 h-2 rounded-full bg-[#ba1a1a] animate-pulse pointer-events-none"></span>
          </div>
        </div>

        {/* Kinetic Hero Container */}
        <div className="hero-kinetic-container relative w-full select-none pt-4 pb-8 sm:pb-12 overflow-hidden min-h-[360px] md:min-h-[460px] flex flex-col justify-center">
          <div className="absolute inset-0 z-0 pointer-events-none w-full h-full flex flex-col justify-between py-2">
            {/* Top row overlays */}
            <div className="w-full flex items-start justify-between font-['Space_Grotesk'] uppercase px-2">
              <div className="flex flex-col items-start gap-1 pointer-events-none select-none">
                <div className="inline-flex items-center gap-2 bg-[#FCF9F8]/90 px-3.5 py-1.5 rounded">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#ba1a1a] pointer-events-none"></span>
                  <span className="text-[#1c1b1b] font-bold tracking-[0.22em] text-[11px] md:text-[13px]">
                    CREATIVE DEVELOPER ARCHIVE
                  </span>
                </div>
              </div>

              <div className="flex justify-end items-start pointer-events-auto select-auto">
                <div className="flex flex-col items-end gap-1.5 text-[12px] md:text-[13px] tracking-[0.2em] font-medium">
                  <div className="relative flex items-center gap-1.5 group cursor-pointer">
                    <span className="line-through decoration-[#a03e35] decoration-[2px] font-bold text-[#1c1b1b]">
                      INTRO
                    </span>
                    <sup className="text-[9px] md:text-[10px] font-mono text-[#ba1a1a] font-bold">01</sup>
                  </div>
                  <a href="#domain-taxonomy" className="flex items-center gap-1.5 text-[#56423f] hover:text-[#1c1b1b] transition-colors cursor-pointer">
                    <span>SPECIALISTS</span>
                    <sup className="text-[9px] md:text-[10px] font-mono text-[#56423f]">02</sup>
                  </a>
                  <a href="#how-it-works-cinematic" className="flex items-center gap-1.5 text-[#56423f] hover:text-[#1c1b1b] transition-colors cursor-pointer">
                    <span>BLUEPRINTS</span>
                    <sup className="text-[9px] md:text-[10px] font-mono text-[#56423f]">03</sup>
                  </a>
                  <a href="#how-it-works-cinematic" className="flex items-center gap-1.5 text-[#56423f] hover:text-[#1c1b1b] transition-colors cursor-pointer">
                    <span>ESCROW PROTOCOL</span>
                    <sup className="text-[9px] md:text-[10px] font-mono text-[#56423f]">04</sup>
                  </a>
                </div>
              </div>
            </div>

            {/* Bottom row status overlay */}
            <div className="w-full flex items-end justify-between font-['Space_Grotesk'] uppercase pb-2 px-2 pointer-events-none">
              <div className="flex flex-col justify-end pointer-events-auto select-auto z-0">
                <div className="bg-[#FCF9F8]/90 backdrop-blur pl-3.5 pr-4 py-2 rounded">
                  <div className="flex items-center gap-1.5 mb-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#590907] animate-pulse pointer-events-none"></span>
                    <span className="font-['Space_Grotesk'] text-[9px] font-mono tracking-widest uppercase text-[#56423f]">
                      STATUS / CAPACITY DISPATCH
                    </span>
                  </div>
                  <p className="font-['Space_Grotesk'] text-[13px] md:text-[14px] leading-[18px] md:leading-[20px] max-w-sm text-[#1c1b1b] tracking-[0.14em] font-bold uppercase">
                    AVAILABLE FOR HIGH-IMPACT
                    <br />
                    ENTERPRISE &amp; BOUTIQUE
                    <br />
                    ENGAGEMENTS
                  </p>
                </div>
              </div>
              <div className="relative flex items-center justify-end pr-[15%] md:pr-[24%] pointer-events-none mb-1">
                <div className="w-2.5 h-2.5 rounded-full bg-[#ba1a1a] animate-pulse self-start mt-1.5 pointer-events-none"></div>
              </div>
            </div>
          </div>

          {/* Dual Brutalist Kinetic Marquee Lines */}
          <div className="relative z-10 w-full flex flex-col justify-center gap-2 pointer-events-none">
            <div className="w-full overflow-hidden flex items-baseline leading-[0.82] pointer-events-none">
              <div className="marquee-row-left text-[17vw] sm:text-[16vw] lg:text-[15.5vw] brutalist-display-text tracking-[-0.055em] pointer-events-none select-none">
                <span className="inline-block whitespace-nowrap" style={{ paddingRight: '85vw' }}>
                  CREATIVE
                </span>
                <span className="inline-block whitespace-nowrap" style={{ paddingRight: '85vw' }}>
                  CREATIVE
                </span>
              </div>
            </div>
            <div className="w-full overflow-hidden flex items-baseline leading-[0.82] mt-1 sm:mt-2 pointer-events-none">
              <div className="marquee-row-right text-[17vw] sm:text-[16vw] lg:text-[15.5vw] brutalist-display-text tracking-[-0.055em] pointer-events-none select-none">
                <span className="inline-block whitespace-nowrap" style={{ paddingRight: '85vw' }}>
                  DEVELOPER
                </span>
                <span className="inline-block whitespace-nowrap" style={{ paddingRight: '85vw' }}>
                  DEVELOPER
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Search Bar Console & Demand Pills */}
        <div className="mt-4 pt-6 border-t-2 border-[#1c1b1b] relative z-20">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-end">
            <div className="lg:col-span-2 flex flex-col justify-end"></div>
            <div className="lg:col-span-7 w-full">
              <form onSubmit={handleSearchSubmit} className="flex flex-col gap-2.5">
                <div className="search-console-container w-full bg-[#ffffff] border border-[#1c1b1b] rounded-lg p-1.5 flex items-center gap-2">
                  <span className="search-icon-symbol material-symbols-outlined text-[20px] text-[#56423f] ml-2">
                    search
                  </span>
                  <input
                    aria-label="Search talent console"
                    className="w-full bg-transparent border-0 focus:outline-none focus:ring-0 font-['Hanken_Grotesk'] text-[15px] text-[#1c1b1b] placeholder:text-[#56423f]/60"
                    placeholder="Search 186,000+ vetted engineers, 3D artists, AI architects..."
                    type="text"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                  />
                  <button
                    className="search-cta-btn px-5 py-2.5 bg-[#1c1b1b] hover:bg-[#590907] text-[#ffffff] font-['Space_Grotesk'] text-[11px] font-bold uppercase tracking-[0.14em] rounded whitespace-nowrap border border-transparent cursor-pointer"
                    type="submit"
                  >
                    Explore Talent
                  </button>
                </div>
                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <span className="font-['Space_Grotesk'] text-[10px] uppercase tracking-[0.18em] text-[#56423f]">
                    In High Demand:
                  </span>
                  {['Shopify Plus', 'Three.js / WebGL', 'AI Agents', 'Brand Systems'].map((pill) => (
                    <button
                      key={pill}
                      className="demand-pill px-2.5 py-0.5 rounded border border-black/15 bg-white/70 font-['Space_Grotesk'] text-[11px] text-[#1c1b1b] cursor-pointer"
                      type="button"
                      onClick={() => handlePillClick(pill)}
                    >
                      {pill}
                    </button>
                  ))}
                </div>
              </form>
            </div>
            <div className="lg:col-span-3 flex flex-col items-start lg:items-end justify-end">
              <div className="text-left lg:text-right">
                <h3 className="font-['Space_Grotesk'] text-xl lg:text-2xl font-bold tracking-tight text-[#1c1b1b] leading-tight">
                  WHO'S
                  <br />
                  TALKING?
                </h3>
                <p className="font-['Space_Grotesk'] text-[10px] uppercase tracking-[0.18em] text-[#56423f] mt-1">
                  THE TOP 3% INDEPENDENT SPECIALISTS
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
