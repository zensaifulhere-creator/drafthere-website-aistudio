import React, { useState, useRef, useEffect } from 'react';
import { generateMonaReply } from '../utils/marketplace';
import { ChatMessage } from '../types';

interface MonaChatbotProps {
  isOpen: boolean;
  onToggle: () => void;
  onClose: () => void;
}

const MONA_AVATAR =
  'https://lh3.googleusercontent.com/aida-public/AB6AXuBJ_IJlEwKHjFw9DRqyhuBDMqDaSu96cAPNA8cIYqcpHYBl2UFR6Z9o-kHSAeLG2kWMMq_dNlw7vp4jmqZORM-t9lYmYOvCUiwwTsk8uij1_eTjXjNwsg6mzfiQgpYG7b79vPwlDW2Aqqjwq2AHVmDRtNI8IkMDOkaLqiZm_aXal3TZnZGG25trEBr9uzxU3bWHGq1TiZiApm3KTPQISIGH3vBVWdTuzAuueT1WnmNoixuSzFo_1y48Lw';

export const MonaChatbot: React.FC<MonaChatbotProps> = ({ isOpen, onToggle, onClose }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'init-1',
      sender: 'mona',
      text: 'Hello! I am MONA, your dedicated intelligent talent concierge. How may I assist your engagement today?',
      time: 'Just now',
    },
  ]);
  const [inputText, setInputText] = useState('');
  const chatScrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [messages, isOpen]);

  const handleSendMessage = (textToSend?: string) => {
    const text = (textToSend || inputText).trim();
    if (!text) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text,
      time: 'Just now',
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');

    setTimeout(() => {
      const replyText = generateMonaReply(text);
      const monaMsg: ChatMessage = {
        id: `mona-${Date.now()}`,
        sender: 'mona',
        text: replyText,
        time: 'Just now',
      };
      setMessages((prev) => [...prev, monaMsg]);
    }, 450);
  };

  return (
    <div
      className="fixed bottom-6 right-6 z-50 flex flex-col items-end pointer-events-none select-none"
      id="concierge-chat-widget"
    >
      {/* Concierge Chat Window */}
      {isOpen && (
        <div
          className="pointer-events-auto mb-3 w-[350px] sm:w-[380px] bg-[#fcf9f8] border border-[#1c1b1b] rounded-2xl shadow-[4px_4px_0px_#1c1b1b] overflow-hidden flex flex-col transition-all duration-300"
          id="concierge-chat-window"
        >
          {/* Header */}
          <div className="bg-[#1c1b1b] text-white px-4 py-3 flex items-center justify-between border-b border-[#1c1b1b]">
            <div className="flex items-center gap-2.5">
              <div className="relative flex items-center justify-center w-9 h-9 rounded-full bg-white border border-black/15 overflow-hidden p-0.5 shadow-sm">
                <img
                  alt="MONA Concierge"
                  className="w-full h-full object-contain"
                  src={MONA_AVATAR}
                />
                <span className="absolute top-0 right-0 w-2.5 h-2.5 rounded-full bg-[#10b981] border border-[#1c1b1b]"></span>
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h4 className="font-['Space_Grotesk'] text-[13px] font-bold tracking-[0.05em] uppercase text-white">
                    MONA Concierge
                  </h4>
                  <span className="px-1.5 py-0.2 bg-[#590907] text-[9px] font-mono tracking-wider rounded text-white font-semibold">
                    AI
                  </span>
                </div>
                <p className="font-['Space_Grotesk'] text-[10px] text-[#ebe7e7]/80 tracking-wider">
                  Online &amp; Calibrated
                </p>
              </div>
            </div>
            <button
              aria-label="Minimize chat"
              className="w-7 h-7 flex items-center justify-center rounded text-white/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
              onClick={onClose}
              type="button"
            >
              <span className="material-symbols-outlined text-[18px]">close</span>
            </button>
          </div>

          {/* Messages & Actions Body */}
          <div
            ref={chatScrollRef}
            className="p-4 bg-[#fcf9f8] flex flex-col gap-3 font-['Hanken_Grotesk'] text-[13px] max-h-[340px] overflow-y-auto"
          >
            {messages.map((m) => (
              <div
                key={m.id}
                className={`flex flex-col ${
                  m.sender === 'user' ? 'items-end' : 'items-start'
                }`}
              >
                <div
                  className={`p-3 rounded-xl max-w-[88%] leading-relaxed ${
                    m.sender === 'user'
                      ? 'bg-[#1c1b1b] text-white rounded-br-none'
                      : 'bg-white border border-black/10 text-[#1c1b1b] rounded-bl-none shadow-sm'
                  }`}
                >
                  {m.text}
                </div>
              </div>
            ))}

            {/* Default Quick Actions */}
            <div className="flex flex-col gap-1.5 pt-1">
              <button
                className="text-left px-3 py-1.5 rounded-lg border border-black/10 bg-white hover:border-[#1c1b1b] text-[12px] font-['Space_Grotesk'] text-[#1c1b1b] transition-all cursor-pointer"
                onClick={() => handleSendMessage('Match vetted Rust engineers')}
                type="button"
              >
                Match vetted Rust engineers
              </button>
              <button
                className="text-left px-3 py-1.5 rounded-lg border border-black/10 bg-white hover:border-[#1c1b1b] text-[12px] font-['Space_Grotesk'] text-[#1c1b1b] transition-all cursor-pointer"
                onClick={() => handleSendMessage('Review milestone escrow protocol')}
                type="button"
              >
                Review milestone escrow protocol
              </button>
            </div>
          </div>

          {/* Input bar */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="p-3 bg-[#f6f3f2] border-t border-black/10 flex items-center gap-2"
          >
            <input
              aria-label="Ask MONA anything"
              className="w-full bg-white border border-black/15 rounded-lg px-3 py-1.5 text-[12px] font-['Hanken_Grotesk'] text-[#1c1b1b] placeholder:text-[#56423f]/70 focus:outline-none focus:border-[#1c1b1b]"
              placeholder="Ask MONA anything..."
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
            />
            <button
              aria-label="Send query"
              className="px-3 py-1.5 bg-[#1c1b1b] text-white rounded-lg hover:bg-[#590907] transition-colors flex items-center justify-center cursor-pointer"
              type="submit"
            >
              <span className="material-symbols-outlined text-[16px]">send</span>
            </button>
          </form>
        </div>
      )}

      {/* Floating Toggle Pill Button */}
      <button
        aria-label="Open Concierge Chat"
        className="pointer-events-auto px-4 py-2.5 rounded-full bg-[#1c1b1b] text-white hover:bg-[#590907] shadow-[2px_2px_0px_rgba(0,0,0,0.25)] flex items-center gap-2 transition-all group border border-white/20 cursor-pointer"
        onClick={onToggle}
        type="button"
      >
        <div className="w-6 h-6 rounded-full overflow-hidden flex items-center justify-center bg-white/10">
          <img
            alt="MONA"
            className="w-full h-full object-contain"
            src={MONA_AVATAR}
          />
        </div>
        <span className="font-['Space_Grotesk'] text-[12px] font-bold tracking-wider uppercase">
          Ask MONA.
        </span>
      </button>
    </div>
  );
};
