import React, { useState } from 'react';
import { CATEGORIES, SUBCATEGORIES } from '../utils/marketplace';

interface DomainTaxonomyProps {
  onSelectSubCategory?: (title: string) => void;
}

export const DomainTaxonomy: React.FC<DomainTaxonomyProps> = ({ onSelectSubCategory }) => {
  const [activeCategoryId, setActiveCategoryId] = useState('dev-it');
  const [activeCardId, setActiveCardId] = useState<string | null>(null);

  // Cards to display
  const currentCards = SUBCATEGORIES.slice(0, 10);

  const handleCategoryClick = (catId: string) => {
    setActiveCategoryId(catId);
  };

  const handleCardClick = (cardId: string, title: string) => {
    setActiveCardId(cardId);
    if (onSelectSubCategory) {
      onSelectSubCategory(title);
    }
  };

  const handleScrollCarousel = (direction: 'left' | 'right') => {
    const track = document.getElementById('categoryTrack');
    if (track) {
      const scrollAmount = direction === 'left' ? -240 : 240;
      track.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  return (
    <section className="w-full px-6 lg:px-12 py-16 bg-[#fcf9f8]" id="domain-taxonomy">
      <div className="max-w-7xl mx-auto">
        {/* Section Heading */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <span className="font-['Space_Grotesk'] text-[11px] uppercase tracking-widest text-[#590907] block mb-1 font-semibold">
              Domain Taxonomy
            </span>
            <h2 className="font-['Space_Grotesk'] text-3xl lg:text-4xl font-semibold text-[#1c1b1b] tracking-tight">
              Find freelancers for every type of work
            </h2>
          </div>
          <div className="flex items-center gap-2">
            <button
              aria-label="Previous categories"
              className="p-2 rounded bg-[#f0edec] hover:bg-[#ebe7e7] transition-colors cursor-pointer"
              type="button"
              onClick={() => handleScrollCarousel('left')}
            >
              <span className="material-symbols-outlined text-[20px]">arrow_back</span>
            </button>
            <button
              aria-label="Next categories"
              className="p-2 rounded bg-[#f0edec] hover:bg-[#ebe7e7] transition-colors cursor-pointer"
              type="button"
              onClick={() => handleScrollCarousel('right')}
            >
              <span className="material-symbols-outlined text-[20px]">arrow_forward</span>
            </button>
          </div>
        </div>

        {/* Category Filter Tabs: Liquid Glass & Full Sibling-Dimming Motion Suite */}
        <div
          className="liquid-marquee-viewport relative py-4 mb-8 overflow-hidden select-none w-full [mask-image:linear-gradient(to_right,transparent_0%,black_6%,black_94%,transparent_100%)] [-webkit-mask-image:linear-gradient(to_right,transparent_0%,black_6%,black_94%,transparent_100%)]"
          style={{
            WebkitFontSmoothing: 'antialiased',
            textRendering: 'optimizeLegibility',
            transform: 'translateZ(0px)',
            backfaceVisibility: 'hidden',
          }}
        >
          <div
            id="categoryTrack"
            className="category-taxonomy-track flex items-center min-w-max gap-6 sm:gap-8 px-2"
            style={{
              WebkitFontSmoothing: 'antialiased',
              textRendering: 'optimizeLegibility',
              transform: 'translateZ(0px)',
              backfaceVisibility: 'hidden',
            }}
          >
            {/* First sequence */}
            <div className="flex items-center gap-6 sm:gap-8 flex-shrink-0">
              {CATEGORIES.map((cat) => {
                const isActive = activeCategoryId === cat.id;
                return (
                  <button
                    key={`cat-1-${cat.id}`}
                    className={`category-filter-item ${
                      isActive ? 'is-active text-[#590907]' : 'text-[#56423f] hover:text-[#590907]'
                    } relative flex flex-col items-center gap-2 group pt-2 pb-2 flex-shrink-0 px-3 cursor-pointer outline-none transition-all duration-300`}
                    type="button"
                    onClick={() => handleCategoryClick(cat.id)}
                  >
                    <div className="liquid-glass-badge relative w-14 h-14 rounded-2xl flex items-center justify-center text-[#1c1b1b] overflow-hidden">
                      <div className="sheen-element"></div>
                      <span
                        className={`material-symbols-outlined text-[24px] ${
                          isActive ? 'text-[#590907]' : 'text-[#56423f]'
                        } group-hover:text-[#590907] relative z-10 transition-transform group-hover:scale-110`}
                      >
                        {cat.icon}
                      </span>
                    </div>
                    <span
                      className={`font-['Space_Grotesk'] text-[12px] ${
                        isActive ? 'font-semibold text-[#590907]' : 'font-medium'
                      } whitespace-nowrap mt-1 group-hover:text-[#590907] transition-colors`}
                    >
                      {cat.label}
                    </span>
                    <span
                      className={`category-oxblood-line h-0.5 w-6 bg-[#590907] rounded-full ${
                        isActive ? 'opacity-100 !scale-x-100' : 'opacity-0'
                      }`}
                    ></span>
                  </button>
                );
              })}
            </div>

            {/* Second sequence for infinite glide */}
            <div aria-hidden="true" className="flex items-center gap-6 sm:gap-8 flex-shrink-0">
              {CATEGORIES.map((cat) => {
                const isActive = activeCategoryId === cat.id;
                return (
                  <button
                    key={`cat-2-${cat.id}`}
                    className={`category-filter-item ${
                      isActive ? 'is-active text-[#590907]' : 'text-[#56423f] hover:text-[#590907]'
                    } relative flex flex-col items-center gap-2 group pt-2 pb-2 flex-shrink-0 px-3 cursor-pointer outline-none transition-all duration-300`}
                    type="button"
                    onClick={() => handleCategoryClick(cat.id)}
                  >
                    <div className="liquid-glass-badge relative w-14 h-14 rounded-2xl flex items-center justify-center text-[#1c1b1b] overflow-hidden">
                      <div className="sheen-element"></div>
                      <span
                        className={`material-symbols-outlined text-[24px] ${
                          isActive ? 'text-[#590907]' : 'text-[#56423f]'
                        } group-hover:text-[#590907] relative z-10 transition-transform group-hover:scale-110`}
                      >
                        {cat.icon}
                      </span>
                    </div>
                    <span
                      className={`font-['Space_Grotesk'] text-[12px] ${
                        isActive ? 'font-semibold text-[#590907]' : 'font-medium'
                      } whitespace-nowrap mt-1 group-hover:text-[#590907] transition-colors`}
                    >
                      {cat.label}
                    </span>
                    <span
                      className={`category-oxblood-line h-0.5 w-6 bg-[#590907] rounded-full ${
                        isActive ? 'opacity-100 !scale-x-100' : 'opacity-0'
                      }`}
                    ></span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Domain Sub-Categories Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {currentCards.map((card) => {
            const isCardActive = activeCardId === card.id;
            return (
              <a
                key={card.id}
                className={`category-card p-6 rounded-xl shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all group flex flex-col justify-between h-36 relative overflow-hidden cursor-pointer border ${
                  isCardActive ? 'is-active !border-[#590907]/30' : 'border-transparent'
                } bg-white/70 backdrop-blur border-black/5`}
                href="#how-it-works-cinematic"
                onClick={(e) => {
                  e.preventDefault();
                  handleCardClick(card.id, card.title);
                }}
              >
                <div
                  className={`category-card-indicator absolute top-0 left-0 right-0 h-1 bg-[#590907] transition-opacity duration-300 pointer-events-none ${
                    isCardActive ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'
                  }`}
                ></div>
                <span className="font-['Space_Grotesk'] text-lg text-[#1c1b1b] group-hover:text-[#590907] transition-colors font-medium">
                  {card.title}
                </span>
                <div className="flex items-center justify-between">
                  <span className="font-['Hanken_Grotesk'] text-[13px] text-[#56423f]">
                    {card.availableCount}
                  </span>
                  <span className="material-symbols-outlined text-[18px] text-[#5d5f55] opacity-0 group-hover:opacity-100 transition-opacity">
                    arrow_forward
                  </span>
                </div>
              </a>
            );
          })}
        </div>
      </div>
    </section>
  );
};
