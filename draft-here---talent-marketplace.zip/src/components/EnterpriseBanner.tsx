import React, { useState } from 'react';

interface EnterpriseBannerProps {
  onBookBriefing?: () => void;
}

export const EnterpriseBanner: React.FC<EnterpriseBannerProps> = ({ onBookBriefing }) => {
  const [showModal, setShowModal] = useState(false);

  return (
    <section className="w-full px-6 lg:px-12 py-16 bg-[#f6f3f2]">
      <div className="max-w-7xl mx-auto rounded-2xl bg-[#1c1b1b]/90 backdrop-blur-xl text-[#fcf9f8] p-8 lg:p-12 shadow-2xl border border-white/10 flex flex-col lg:flex-row items-center justify-between gap-8 relative overflow-hidden [box-shadow:0_20px_50px_rgba(0,0,0,0.4),inset_0_1px_0_rgba(255,255,255,0.18)] group">
        <div className="absolute -right-16 -bottom-16 w-96 h-96 rounded-full bg-[#590907]/40 opacity-70 blur-3xl pointer-events-none transition-all duration-700 group-hover:scale-110"></div>
        <div className="absolute -left-16 -top-16 w-80 h-80 rounded-full bg-[#360001]/30 opacity-60 blur-3xl pointer-events-none"></div>

        <div className="relative z-10 max-w-xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/15 shadow-[inset_0_1px_0_rgba(255,255,255,0.2)] mb-4">
            <span className="w-1.5 h-1.5 rounded-full bg-[#10b981] animate-pulse"></span>
            <span className="font-['Space_Grotesk'] text-[11px] uppercase tracking-[0.2em] text-[#f6dfc2] font-semibold">
              Enterprise Concierge
            </span>
          </div>
          <h2 className="font-['Space_Grotesk'] text-3xl font-semibold text-[#fcf9f8] tracking-tight mb-2">
            Need a fully assembled guild for an upcoming launch?
          </h2>
          <p className="font-['Hanken_Grotesk'] text-[15px] text-[#dcd9d9] font-light leading-relaxed">
            Draft Here matches venture-backed organizations and high-growth brands with specialized multi-disciplinary pods in less than 24 hours.
          </p>
        </div>

        <div className="relative z-10 flex flex-col sm:flex-row items-center gap-4 w-full lg:w-auto">
          <button
            className="w-full sm:w-auto px-6 py-3 bg-[#fcf9f8] text-[#1c1b1b] hover:bg-[#f6dfc2] hover:shadow-[0_0_25px_rgba(246,223,194,0.35)] font-['Space_Grotesk'] text-[13px] uppercase tracking-wider rounded font-semibold transition-all hover:-translate-y-0.5 shadow-md flex items-center justify-center gap-2 cursor-pointer"
            type="button"
            onClick={() => {
              if (onBookBriefing) onBookBriefing();
              setShowModal(true);
            }}
          >
            <span>Book Studio Briefing</span>
            <span className="material-symbols-outlined text-[16px]">calendar_today</span>
          </button>
          <a
            className="w-full sm:w-auto px-5 py-3 bg-white/5 hover:bg-white/10 border border-white/15 text-[#fcf9f8] hover:text-[#f6dfc2] font-['Space_Grotesk'] text-[13px] uppercase tracking-wider font-semibold transition-all hover:-translate-y-0.5 rounded flex items-center justify-center gap-1.5 shadow-[inset_0_1px_0_rgba(255,255,255,0.1)] cursor-pointer"
            href="#how-it-works-cinematic"
          >
            <span>Read Enterprise SLAs</span>
            <span className="material-symbols-outlined text-[16px] group-hover:translate-x-0.5 transition-transform">
              arrow_forward
            </span>
          </a>
        </div>
      </div>

      {/* Briefing Modal */}
      {showModal && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
          onClick={() => setShowModal(false)}
        >
          <div
            className="bg-[#fcf9f8] rounded-2xl border-2 border-[#1c1b1b] p-6 sm:p-8 max-w-lg w-full shadow-[10px_10px_0px_#1c1b1b] relative"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-4 border-b border-black/10 mb-4">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#10b981]"></span>
                <span className="font-['Space_Grotesk'] text-[12px] font-mono tracking-widest uppercase text-[#590907] font-bold">
                  DIRECT CONCIERGE DISPATCH
                </span>
              </div>
              <button
                className="w-8 h-8 rounded-full border border-black/10 hover:bg-black/5 flex items-center justify-center"
                onClick={() => setShowModal(false)}
                type="button"
                aria-label="Close dialog"
              >
                <span className="material-symbols-outlined text-[20px]">close</span>
              </button>
            </div>
            <h3 className="font-['Space_Grotesk'] text-2xl font-bold text-[#1c1b1b] mb-2">
              Book Studio Briefing
            </h3>
            <p className="font-['Hanken_Grotesk'] text-[14px] text-[#56423f] mb-6 leading-relaxed">
              Our partner architect team evaluates scope requirements and provisions tailored talent pods within 24 hours. Contact our team directly or dispatch an architectural request:
            </p>
            <div className="space-y-3 mb-6">
              <div className="p-3 bg-white border border-black/10 rounded-xl flex items-center justify-between">
                <span className="text-[13px] font-['Space_Grotesk'] font-medium text-[#1c1b1b]">Direct Hotline:</span>
                <a href="mailto:concierge@drafthere.com" className="text-[13px] font-mono font-bold text-[#590907] hover:underline">
                  concierge@drafthere.com
                </a>
              </div>
              <div className="p-3 bg-white border border-black/10 rounded-xl flex items-center justify-between">
                <span className="text-[13px] font-['Space_Grotesk'] font-medium text-[#1c1b1b]">Average Pod Assembly:</span>
                <span className="text-[13px] font-mono font-bold text-[#10b981]">18.4 Hours</span>
              </div>
            </div>
            <div className="flex gap-3">
              <button
                type="button"
                className="flex-1 py-2.5 bg-[#1c1b1b] text-white rounded-lg font-['Space_Grotesk'] text-[12px] font-bold uppercase tracking-wider hover:bg-[#590907] transition-colors"
                onClick={() => {
                  window.location.href = 'mailto:concierge@drafthere.com?subject=Studio%20Briefing%20Request';
                  setShowModal(false);
                }}
              >
                Launch Mail Dispatch
              </button>
              <button
                type="button"
                className="px-4 py-2.5 border border-black/20 rounded-lg font-['Space_Grotesk'] text-[12px] font-medium hover:bg-black/5"
                onClick={() => setShowModal(false)}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
