import React, { useState, useEffect } from 'react';
import { MILESTONE_PHASES } from '../utils/marketplace';
import { MilestonePhase } from '../types';

export const HowItWorks: React.FC = () => {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const handleCardClick = (phaseId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setExpandedId((prev) => (prev === phaseId ? null : phaseId));
  };

  useEffect(() => {
    const handleGlobalClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest('.atelier-frosted-card')) {
        setExpandedId(null);
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setExpandedId(null);
      }
    };

    document.addEventListener('click', handleGlobalClick);
    document.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('click', handleGlobalClick);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  const renderCard = (phase: MilestonePhase, suffix: string) => {
    const isExpanded = expandedId === `${phase.id}-${suffix}`;

    return (
      <div
        key={`${phase.id}-${suffix}`}
        className={`atelier-frosted-card w-[340px] sm:w-[380px] p-8 rounded-2xl relative group flex flex-col justify-between flex-shrink-0 select-auto border shadow-sm hover:shadow-md transition-all bg-transparent backdrop-blur-md border-transparent hover:border-[#590907]/40 hover:shadow-xl hover:-translate-y-1.5 duration-500 ease-out cursor-pointer ${
          isExpanded ? 'is-expanded' : ''
        }`}
        onClick={(e) => handleCardClick(`${phase.id}-${suffix}`, e)}
      >
        <div>
          <div className="flex items-center justify-between mb-6">
            <div
              className={`badge-glow w-13 h-13 px-4 py-2.5 rounded-xl ${phase.badgeBg} ${phase.badgeTextColor} font-['Space_Grotesk'] text-[18px] font-bold border border-black/10 flex items-center justify-center`}
            >
              {phase.phaseNum}
            </div>
            <span className="font-['Space_Grotesk'] text-[10px] font-mono tracking-widest text-[#56423f] uppercase bg-black/5 px-2.5 py-1 rounded-full">
              {phase.phaseBadge}
            </span>
          </div>
          <h3 className="font-['Space_Grotesk'] text-[19px] text-[#1c1b1b] mb-2.5 font-bold tracking-tight group-hover:text-[#590907] transition-colors">
            {phase.title}
          </h3>
          <p className="font-['Hanken_Grotesk'] text-[14px] leading-relaxed text-[#56423f] mb-4">
            {phase.description}
          </p>
          <div className="milestone-drawer border-t border-black/10 pt-3 flex flex-col gap-2 font-['Hanken_Grotesk'] text-[12px] text-[#56423f]">
            {phase.specs.map((spec, sIdx) => (
              <div
                key={sIdx}
                className={`flex items-center justify-between py-1 ${
                  sIdx < phase.specs.length - 1 ? 'border-b border-black/5' : ''
                }`}
              >
                <span className="font-['Space_Grotesk'] font-bold text-[#1c1b1b] uppercase text-[10px] tracking-wider">
                  {spec.label}
                </span>
                <span
                  className={
                    spec.highlight
                      ? 'text-[11px] font-bold text-[#10b981]'
                      : 'font-mono text-[11px] text-[#590907] font-semibold'
                  }
                >
                  {spec.value}
                </span>
              </div>
            ))}
          </div>
        </div>
        <div className="pt-4 border-t border-black/5 flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-[#590907] font-['Space_Grotesk'] text-[12px] font-semibold">
            <span className="material-symbols-outlined text-[17px] group-hover:scale-110 transition-transform">
              {phase.actionIcon}
            </span>
            <span className="card-action-label">
              {isExpanded ? 'Collapse Specs' : 'Inspect Phase Specs'}
            </span>
          </div>
          <span className="expand-toggle-icon material-symbols-outlined text-[18px] text-[#56423f]/70 group-hover:text-[#590907] transition-all">
            expand_more
          </span>
        </div>
      </div>
    );
  };

  return (
    <section
      className="w-full px-4 sm:px-6 lg:px-12 py-20 relative overflow-hidden bg-[#f3f0ef]/80 border-y border-black/5"
      id="how-it-works-cinematic"
    >
      <div
        className="absolute top-1/2 left-1/2 w-[700px] h-[340px] bg-gradient-to-r from-[#ffdad5]/20 via-[#f6dfc2]/30 to-[#590907]/10 rounded-full blur-3xl pointer-events-none -translate-x-1/2 -translate-y-1/2"
        style={{ animation: 'pulseRadialGlow 9s ease-in-out infinite' }}
      ></div>

      <div className="w-full max-w-[1520px] mx-auto relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-14 relative px-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/90 border border-black/10 shadow-[0_1px_4px_rgba(0,0,0,0.02)] mb-3">
            <span className="w-1.5 h-1.5 rounded-full bg-[#590907] animate-pulse"></span>
            <span className="font-['Space_Grotesk'] text-[11px] uppercase tracking-[0.2em] text-[#590907] font-bold">
              Standard of Engagement
            </span>
          </div>
          <h2 className="font-['Space_Grotesk'] text-3xl sm:text-4xl lg:text-[42px] font-bold tracking-tight mb-3 leading-[1.12] uppercase text-[#1c1b1b]">
            Architectural Rigor from Scope to Escrow Release
          </h2>
          <p className="font-['Hanken_Grotesk'] text-[15px] sm:text-[16px] text-[#56423f] leading-relaxed max-w-2xl mx-auto">
            Engineered to eliminate administrative friction and guarantee bespoke precision for both elite enterprises and independent practitioners.
          </p>
        </div>

        <div
          id="milestoneMarqueeContainer"
          className={`engagement-marquee-container relative w-full overflow-hidden py-4 select-none ${
            expandedId ? 'has-expanded' : ''
          }`}
        >
          <div
            className="engagement-marquee-track flex items-center gap-6 sm:gap-8 will-change-transform"
            style={{
              display: 'flex',
              width: 'max-content',
              animation: 'engagementGlideLeft 38s linear infinite',
              animationPlayState: expandedId ? 'paused' : undefined,
            }}
          >
            {/* Loop 1 */}
            <div className="flex items-stretch gap-6 sm:gap-8 flex-shrink-0">
              {MILESTONE_PHASES.map((phase) => renderCard(phase, 'track1'))}
            </div>

            {/* Loop 2 */}
            <div aria-hidden="true" className="flex items-stretch gap-6 sm:gap-8 flex-shrink-0">
              {MILESTONE_PHASES.map((phase) => renderCard(phase, 'track2'))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
