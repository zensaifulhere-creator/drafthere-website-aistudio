import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="w-full bg-[#f6f3f2] mt-16 shadow-[0_-1px_12px_rgba(0,0,0,0.02)]">
      <div className="w-full px-6 lg:px-12 py-12 max-w-[1520px] mx-auto">
        {/* Cinematic Frosted Glass Trust Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {/* Card 1 */}
          <div className="trust-cinematic-card flex items-start gap-4 p-5 sm:p-6 rounded-2xl relative overflow-hidden group cursor-default">
            <div className="trust-icon-badge w-12 h-12 rounded-xl bg-[#e2e4d6]/80 backdrop-blur-md flex items-center justify-center text-[#1a1d15] flex-shrink-0 border border-black/5 shadow-sm group-hover:bg-[#e2e4d6]">
              <span className="material-symbols-outlined text-[24px]">verified_user</span>
            </div>
            <div>
              <h4 className="font-['Space_Grotesk'] text-lg text-[#1c1b1b] mb-1 font-bold tracking-tight group-hover:text-[#590907] transition-colors">
                Client Protection Guarantee
              </h4>
              <p className="font-['Hanken_Grotesk'] text-[13.5px] text-[#56423f] leading-relaxed">
                Funds are retained in audited escrow until contracts and deliverables are signed off to precision.
              </p>
            </div>
          </div>

          {/* Card 2 */}
          <div className="trust-cinematic-card flex items-start gap-4 p-5 sm:p-6 rounded-2xl relative overflow-hidden group cursor-default">
            <div className="trust-icon-badge w-12 h-12 rounded-xl bg-[#f6dfc2]/80 backdrop-blur-md flex items-center justify-center text-[#251a08] flex-shrink-0 border border-black/5 shadow-sm group-hover:bg-[#f6dfc2]">
              <span className="material-symbols-outlined text-[24px]">workspace_premium</span>
            </div>
            <div>
              <h4 className="font-['Space_Grotesk'] text-lg text-[#1c1b1b] mb-1 font-bold tracking-tight group-hover:text-[#590907] transition-colors">
                Curated Artisan Standard
              </h4>
              <p className="font-['Hanken_Grotesk'] text-[13.5px] text-[#56423f] leading-relaxed">
                The top 3% of global specialists across engineering, design, and computational systems.
              </p>
            </div>
          </div>

          {/* Card 3 */}
          <div className="trust-cinematic-card flex items-start gap-4 p-5 sm:p-6 rounded-2xl relative overflow-hidden group cursor-default">
            <div className="trust-icon-badge w-12 h-12 rounded-xl bg-[#ffdad5]/80 backdrop-blur-md flex items-center justify-center text-[#410001] flex-shrink-0 border border-black/5 shadow-sm group-hover:bg-[#ffdad5]">
              <span className="material-symbols-outlined text-[24px]">support_agent</span>
            </div>
            <div>
              <h4 className="font-['Space_Grotesk'] text-lg text-[#1c1b1b] mb-1 font-bold tracking-tight group-hover:text-[#590907] transition-colors">
                Dedicated Concierge 24/7
              </h4>
              <p className="font-['Hanken_Grotesk'] text-[13.5px] text-[#56423f] leading-relaxed">
                White-glove project facilitation and mediator support for elite enterprise engagements.
              </p>
            </div>
          </div>
        </div>

        {/* Footer Navigation Columns */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8 py-8">
          <div className="col-span-2 lg:col-span-2">
            <div className="flex items-center gap-3 mb-5">
              <img
                alt="Draft Here"
                className="w-auto object-contain h-20 sm:h-24 md:h-26 hover:scale-105 transition-transform"
                style={{ height: '92px' }}
                src="/assets/aistudio/file_00000000442481f4bd27237d4de0866c-cutout_57552ceb.png"
              />
            </div>
            <p className="font-['Hanken_Grotesk'] text-[15px] text-[#56423f] max-w-sm mb-6">
              The premier editorial freelance exchange. Precision-crafted work units, architectural contracts, and peerless talent curation.
            </p>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1 px-3 py-1 rounded bg-[#f0edec] text-[#1c1b1b] font-['Space_Grotesk'] text-[11px] font-semibold">
                <span className="material-symbols-outlined text-[16px]">language</span>
                <span>EN (Global)</span>
              </div>
              <div className="flex items-center gap-1 px-3 py-1 rounded bg-[#f0edec] text-[#1c1b1b] font-['Space_Grotesk'] text-[11px] font-semibold">
                <span className="material-symbols-outlined text-[16px]">payments</span>
                <span>USD ($)</span>
              </div>
            </div>
          </div>

          <div>
            <h5 className="font-['Space_Grotesk'] text-[13px] uppercase tracking-wider text-[#1c1b1b] mb-4 font-semibold">
              Categories
            </h5>
            <ul className="space-y-2 font-['Hanken_Grotesk'] text-[13px] text-[#56423f]">
              <li>
                <a className="hover:text-[#590907] transition-colors" href="#domain-taxonomy">
                  Dev &amp; IT Solutions
                </a>
              </li>
              <li>
                <a className="hover:text-[#590907] transition-colors" href="#domain-taxonomy">
                  Art &amp; Design Direction
                </a>
              </li>
              <li>
                <a className="hover:text-[#590907] transition-colors" href="#domain-taxonomy">
                  Machine Learning &amp; AI
                </a>
              </li>
              <li>
                <a className="hover:text-[#590907] transition-colors" href="#domain-taxonomy">
                  Growth &amp; Editorial Strategy
                </a>
              </li>
              <li>
                <a className="hover:text-[#590907] transition-colors" href="#domain-taxonomy">
                  Cinematics &amp; Motion
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h5 className="font-['Space_Grotesk'] text-[13px] uppercase tracking-wider text-[#1c1b1b] mb-4 font-semibold">
              Marketplace
            </h5>
            <ul className="space-y-2 font-['Hanken_Grotesk'] text-[13px] text-[#56423f]">
              <li>
                <a className="hover:text-[#590907] transition-colors" href="#domain-taxonomy">
                  Explore Directory
                </a>
              </li>
              <li>
                <a className="hover:text-[#590907] transition-colors" href="#">
                  Apply as Talent
                </a>
              </li>
              <li>
                <a className="hover:text-[#590907] transition-colors" href="#">
                  Enterprise Retainers
                </a>
              </li>
              <li>
                <a className="hover:text-[#590907] transition-colors" href="#domain-taxonomy">
                  Curated Portfolios
                </a>
              </li>
              <li>
                <a className="hover:text-[#590907] transition-colors" href="#how-it-works-cinematic">
                  Standard Contracts
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h5 className="font-['Space_Grotesk'] text-[13px] uppercase tracking-wider text-[#1c1b1b] mb-4 font-semibold">
              Governance
            </h5>
            <ul className="space-y-2 font-['Hanken_Grotesk'] text-[13px] text-[#56423f]">
              <li>
                <a className="hover:text-[#590907] transition-colors" href="#how-it-works-cinematic">
                  Trust &amp; Escrow
                </a>
              </li>
              <li>
                <a className="hover:text-[#590907] transition-colors" href="#">
                  Terms of Service
                </a>
              </li>
              <li>
                <a className="hover:text-[#590907] transition-colors" href="#">
                  Privacy Architecture
                </a>
              </li>
              <li>
                <a className="hover:text-[#590907] transition-colors" href="#how-it-works-cinematic">
                  IP Assignment
                </a>
              </li>
              <li>
                <a className="hover:text-[#590907] transition-colors" href="mailto:concierge@drafthere.com">
                  Dispute Concierge
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Legal Notice */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-black/5">
          <p className="font-['Space_Grotesk'] text-[11px] text-[#5d5f55]">
            © 2025 Draft Here Studio Inc. All rights reserved. Curated digital craft.
          </p>
          <div className="flex items-center gap-6 font-['Space_Grotesk'] text-[11px] text-[#5d5f55]">
            <a className="hover:text-[#1c1b1b] transition-colors" href="#">
              Privacy
            </a>
            <a className="hover:text-[#1c1b1b] transition-colors" href="#">
              Terms
            </a>
            <a className="hover:text-[#1c1b1b] transition-colors" href="#">
              System Status
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};
