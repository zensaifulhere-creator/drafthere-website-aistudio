export interface CategoryTab {
  id: string;
  label: string;
  icon: string;
}

export interface SubCategory {
  id: string;
  title: string;
  availableCount: string;
  categoryId: string;
}

export interface MilestonePhase {
  id: string;
  phaseNum: string;
  phaseBadge: string;
  badgeBg: string;
  badgeTextColor: string;
  title: string;
  description: string;
  specs: {
    label: string;
    value: string;
    highlight?: boolean;
  }[];
  actionIcon: string;
}

export interface TestimonialCardData {
  id: string;
  number: string;
  name: string;
  role: string;
  avatar: string;
  stars: number;
  quote: string;
  guild: string;
  badge: string;
  bgColor: string;
  textColor?: string;
  subTextColor?: string;
  badgeBg?: string;
  badgeTextColor?: string;
  baseTilt: string;
  hoverTransform: string;
  positionClasses: string;
}

export interface ChatMessage {
  id: string;
  sender: 'mona' | 'user';
  text: string;
  time: string;
}
